!function (l) {
    "use strict";
    function e() {
        this.$body = l("body"),
            this.$modal = l("#event-modal"),
            this.$calendar = l("#calendar"),
            this.$formEvent = l("#form-event"),
            this.$btnNewEvent = l("#btn-new-event"),
            this.$btnDeleteEvent = l("#btn-delete-event"),
            this.$btnSaveEvent = l("#btn-save-event"),
            this.$modalTitle = l("#modal-title"),
            this.$calendarObj = null,
            this.$selectedEvent = null,
            this.$newEventData = null
    }

    e.prototype.onEventClick = function (e) {
        this.$formEvent[0].reset(),
            this.$formEvent.removeClass("was-validated"),
            this.$newEventData = null,
            this.$btnDeleteEvent.show(),
            this.$modalTitle.text("Edit Event"),
            this.$modal.show(),
            this.$selectedEvent = e.event,
            l("#event-title").val(this.$selectedEvent.title),
            l("#event-category").val(this.$selectedEvent.classNames[0]),
            l("#start-date").val(this.formatDate(this.$selectedEvent.start)),
            l("#end-date").val(this.formatDate(this.$selectedEvent.end))
    };

    e.prototype.onSelect = function (e) {
        try {
            this.$formEvent[0].reset();
        } catch (error) {
            console.error("Form reset failed:", error);
        }
        this.$formEvent.removeClass("was-validated");
        this.$selectedEvent = null;
        this.$newEventData = e;
        this.$btnDeleteEvent.hide();
        this.$modalTitle.text("Add New Event");

        const isAllDay = e.allDay !== undefined ? e.allDay : true;
        const startDate = this.formatDate(e.start);
        const endDate = e.end ? this.formatDate(e.end) : startDate;
        l("#start-date").val(startDate);
        l("#end-date").val(endDate);
        l("#event-category").val(this.$selectedEvent.classNames[0]),
            l("#all-day-checkbox").prop('checked', isAllDay);

        this.$modal.show();
        this.$calendarObj.unselect();
    };

    e.prototype.formatDate = function (date) {
        if (!date) return '';
        var year = date.getFullYear(),
            month = String(date.getMonth() + 1).padStart(2, '0'),
            day = String(date.getDate()).padStart(2, '0'),
            hours = String(date.getHours()).padStart(2, '0'),
            minutes = String(date.getMinutes()).padStart(2, '0');
        return `${year}-${month}-${day}T${hours}:${minutes}`;
    };

    new FullCalendar.Draggable(document.getElementById("external-events"), {
        itemSelector: ".external-event", eventData: function (e) {
            return { title: e.innerText, className: l(e).data("class") };
        }
    });

    e.prototype.init = function () {
        this.$modal = new bootstrap.Modal(document.getElementById("event-modal"), { keyboard: !1 });

        this.$btnNewEvent.on("click", function (e) {
            this.onSelect({ date: new Date, allDay: !0 });
        }.bind(this));

        this.$btnDeleteEvent.on("click", function (e) {
            this.$selectedEvent && (this.$selectedEvent.remove(), this.$selectedEvent = null, this.$modal.hide());
        }.bind(this));

        l("#external-events .external-event").each(function () {
            var eventClass = l(this).data("class");

            l(this).on("click", function () {
                this.onSelect({
                    start: new Date(),
                    end: new Date(),
                    allDay: true,
                    classNames: [eventClass]
                });
            }.bind(this));
        });
    };

    l.CalendarApp = new e;
    l.CalendarApp.Constructor = e;

}(window.jQuery);

//
// !function (l) {
//     "use strict";
//     function e() {
//         this.$body = l("body"),
//             this.$modal = l("#event-modal"),
//             this.$calendar = l("#calendar"),
//             this.$formEvent = l("#form-event"),
//             this.$btnNewEvent = l("#btn-new-event"),
//             this.$btnDeleteEvent = l("#btn-delete-event"),
//             this.$btnSaveEvent = l("#btn-save-event"),
//             this.$modalTitle = l("#modal-title"),
//             this.$calendarObj = null,
//             this.$selectedEvent = null,
//             this.$newEventData = null
//     }

//     // Event click to edit an existing event
//     e.prototype.onEventClick = function (e) {
//         this.$formEvent[0].reset(),
//             this.$formEvent.removeClass("was-validated"),
//             this.$newEventData = null,
//             this.$btnDeleteEvent.show(),
//             this.$modalTitle.text("Edit Event"),
//             this.$modal.show(),
//             this.$selectedEvent = e.event,
//             l("#event-title").val(this.$selectedEvent.title),
//             l("#event-category").val(this.$selectedEvent.classNames[0]),
//             l("#start-date").val(this.formatDate(this.$selectedEvent.start)),
//             l("#end-date").val(this.formatDate(this.$selectedEvent.end))
//     };

//     // Select function to handle both single and multi-day selection
//     e.prototype.onSelect = function (e) {
//         this.$formEvent[0].reset();
//         this.$formEvent.removeClass("was-validated");
//         this.$selectedEvent = null;
//         this.$newEventData = e;  // Store the event data for later use
//         this.$btnDeleteEvent.hide();
//         this.$modalTitle.text("Add New Event");

//         // Initialize allDay based on the selection (default to true if it's a new event)
//         const isAllDay = e.allDay !== undefined ? e.allDay : true;  // Default to true if not set

//         // Prefill modal fields with selected date range (multi-day support)
//         const startDate = this.formatDate(e.start);  // Use custom formatting function
//         const endDate = e.end ? this.formatDate(e.end) : startDate; // If end exists, use it; otherwise, it's a single day event

//         l("#start-date").val(startDate);
//         l("#end-date").val(endDate);
//         l("#all-day-checkbox").prop('checked', isAllDay);  // Update all-day checkbox based on the selection

//         this.$modal.show();
//         this.$calendarObj.unselect(); // Unselect dates from the calendar after opening the modal
//     };


//     // Function to format the Date object into a datetime-local compatible string
//     e.prototype.formatDate = function (date) {
//         if (!date) return '';
//         // Format the date as 'YYYY-MM-DDTHH:MM'
//         var year = date.getFullYear(),
//             month = String(date.getMonth() + 1).padStart(2, '0'),
//             day = String(date.getDate()).padStart(2, '0'),
//             hours = String(date.getHours()).padStart(2, '0'),
//             minutes = String(date.getMinutes()).padStart(2, '0');
//         return `${year}-${month}-${day}T${hours}:${minutes}`;
//     };

//     // Initialize FullCalendar
//     e.prototype.init = function () {
//         this.$modal = new bootstrap.Modal(document.getElementById("event-modal"), { keyboard: !1 });

//         // Setup the calendar with draggable events and other options
//         var e = new Date(l.now());
//         new FullCalendar.Draggable(document.getElementById("external-events"), {
//             itemSelector: ".external-event", eventData: function (e) {
//                 return { title: e.innerText, className: l(e).data("class") };
//             }
//         });

//         var t = [
//             { title: "Meeting with Mr. Shreyu", start: new Date(l.now() + 158e6), end: new Date(l.now() + 338e6), className: "bg-warning" },
//             { title: "Interview - Backend Engineer", start: e, end: e, className: "bg-success" },
//             { title: "Phone Screen - Frontend Engineer", start: new Date(l.now() + 168e6), className: "bg-info" },
//             { title: "Buy Design Assets", start: new Date(l.now() + 338e6), end: new Date(l.now() + 4056e5), className: "bg-primary" }
//         ];

//         var a = this;
//         a.$calendarObj = new FullCalendar.Calendar(a.$calendar[0], {
//             slotDuration: "00:15:00",
//             slotMinTime: "08:00:00",
//             slotMaxTime: "19:00:00",
//             themeSystem: "bootstrap",
//             bootstrapFontAwesome: !1,
//             buttonText: { today: "Today", month: "Month", week: "Week", day: "Day", list: "List", prev: "Prev", next: "Next" },
//             initialView: "dayGridMonth",
//             handleWindowResize: !0,
//             height: l(window).height() - 200,
//             headerToolbar: { left: "prev,next today", center: "title", right: "dayGridMonth,timeGridWeek,timeGridDay,listMonth" },
//             initialEvents: t,
//             editable: !0,
//             droppable: !0,
//             selectable: !0,
//             dateClick: function (e) { a.onSelect(e) },
//             select: function (e) { a.onSelect(e) },
//             eventClick: function (e) { a.onEventClick(e) }
//         });

//         a.$calendarObj.render();

//         // New event button click
//         a.$btnNewEvent.on("click", function (e) {
//             a.onSelect({ date: new Date, allDay: !0 });
//         });

//         // Form submit for saving the event
//         // Form submit for saving the event
//         a.$formEvent.on("submit", function (e) {
//             e.preventDefault();
//             var t, n = a.$formEvent[0];
//             const isAllDay = l("#all-day-checkbox").prop('checked');  // Get the value of the "All Day" checkbox

//             n.checkValidity() ? (a.$selectedEvent ?
//                 (a.$selectedEvent.setProp("title", l("#event-title").val()),
//                     a.$selectedEvent.setProp("classNames", [l("#event-category").val()]),
//                     a.$selectedEvent.setStart(new Date(l("#start-date").val())),
//                     a.$selectedEvent.setEnd(new Date(l("#end-date").val())),
//                     a.$selectedEvent.setAllDay(isAllDay)) :  // Set allDay property for the event
//                 (t = {
//                     title: l("#event-title").val(),
//                     start: new Date(l("#start-date").val()),
//                     end: new Date(l("#end-date").val()),
//                     allDay: isAllDay,  // Pass allDay to the event data
//                     className: l("#event-category").val()
//                 },
//                     a.$calendarObj.addEvent(t)),
//                 a.$modal.hide()) :
//                 (e.stopPropagation(), n.classList.add("was-validated"));
//         });


//         // Delete event button click
//         l(a.$btnDeleteEvent.on("click", function (e) {
//             a.$selectedEvent && (a.$selectedEvent.remove(), a.$selectedEvent = null, a.$modal.hide());
//         }));
//     };

//     l.CalendarApp = new e;
//     l.CalendarApp.Constructor = e;
// }(window.jQuery);
