-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2025 at 04:15 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `calendarinfo`
--

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `coid` int(11) NOT NULL,
  `coname` varchar(255) NOT NULL,
  `coperson` varchar(255) NOT NULL,
  `conumber` varchar(255) NOT NULL,
  `coemail` varchar(255) NOT NULL,
  `coaddress1` varchar(255) NOT NULL,
  `coaddress2` varchar(255) DEFAULT NULL,
  `cocity` varchar(255) NOT NULL,
  `costate` int(11) NOT NULL,
  `cozip` varchar(255) NOT NULL,
  `copan` varchar(255) NOT NULL,
  `cogst` varchar(255) NOT NULL,
  `colinkedin` longtext NOT NULL,
  `cofacebook` longtext NOT NULL,
  `coinstagram` longtext NOT NULL,
  `coyoutube` longtext NOT NULL,
  `createdby` int(11) NOT NULL,
  `createdate` datetime NOT NULL,
  `modifyby` int(11) DEFAULT NULL,
  `modifydate` datetime DEFAULT NULL,
  `deletedby` tinyint(4) DEFAULT NULL,
  `deleteddate` datetime DEFAULT NULL,
  `active` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`coid`, `coname`, `coperson`, `conumber`, `coemail`, `coaddress1`, `coaddress2`, `cocity`, `costate`, `cozip`, `copan`, `cogst`, `colinkedin`, `cofacebook`, `coinstagram`, `coyoutube`, `createdby`, `createdate`, `modifyby`, `modifydate`, `deletedby`, `deleteddate`, `active`) VALUES
(1, 'GreenHill Consulting LLP', 'Kruti Chauhan', '8291100407', 'connect@ghconsulting.in', 'ZENIA BUILDING, Hiranandani Business Park', 'Arcadia Cir, Hiranandani Estate', 'Thane West', 21, '400607', 'ABGPP7178P', '24ABGPP7178P1ZU', 'https://in.linkedin.com/company/greenhill-consulting-llp', 'https://www.facebook.com/greenhill.consulting.llp.in/', 'https://www.instagram.com/greenhill.consulting.llp/', 'https://www.youtube.com/@GreenhillConsultingLLP/about', 1, '2023-12-14 22:44:55', 1, '2024-11-14 12:16:25', NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `holidays`
--

CREATE TABLE `holidays` (
  `hid` int(11) NOT NULL,
  `htitle` longtext NOT NULL,
  `hcategory` longtext NOT NULL,
  `hstartdate` datetime NOT NULL,
  `henddate` datetime NOT NULL,
  `hdesc` longtext DEFAULT NULL,
  `createby` int(11) NOT NULL,
  `createdate` datetime NOT NULL,
  `modifyby` int(11) DEFAULT NULL,
  `modifydate` datetime DEFAULT NULL,
  `deleteby` int(11) DEFAULT NULL,
  `deletedate` datetime DEFAULT NULL,
  `active` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `holidays`
--

INSERT INTO `holidays` (`hid`, `htitle`, `hcategory`, `hstartdate`, `henddate`, `hdesc`, `createby`, `createdate`, `modifyby`, `modifydate`, `deleteby`, `deletedate`, `active`) VALUES
(1, 'Sumit Meeting', 'bg-info', '2025-04-28 08:30:00', '2025-04-28 08:30:00', NULL, 1, '2025-04-28 16:02:58', 1, '2025-04-28 16:04:43', NULL, NULL, 1),
(2, 'Sumit Meeting', 'bg-info', '2025-04-28 04:00:00', '2025-04-29 11:00:00', NULL, 1, '2025-04-28 16:03:00', 1, '2025-04-28 16:12:33', NULL, NULL, 1),
(3, 'Evening', 'bg-dark', '2025-04-24 08:45:00', '2025-04-28 03:30:00', NULL, 1, '2025-04-28 16:14:13', NULL, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` int(255) NOT NULL,
  `userid` bigint(20) UNSIGNED DEFAULT NULL,
  `sessionkey` varchar(45) DEFAULT NULL,
  `sessionip` longtext NOT NULL,
  `createdate` datetime NOT NULL,
  `active` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `userid`, `sessionkey`, `sessionip`, `createdate`, `active`) VALUES
(6, 1, 'hoto3551s85o36h8v0bfmk060a', '::1', '2024-11-11 13:00:03', 0),
(7, 1, '3c7tqjgap8chce3hae56fil91g', '::1', '2024-11-12 10:56:00', 1),
(8, 1, '3c7tqjgap8chce3hae56fil91g', '::1', '2024-11-12 10:56:06', 1),
(9, 1, '3c7tqjgap8chce3hae56fil91g', '::1', '2024-11-12 10:56:57', 1),
(10, 1, '3c7tqjgap8chce3hae56fil91g', '::1', '2024-11-12 10:57:29', 1),
(11, 1, '3c7tqjgap8chce3hae56fil91g', '::1', '2024-11-12 10:57:48', 1),
(12, 1, '3c7tqjgap8chce3hae56fil91g', '::1', '2024-11-12 10:58:00', 1),
(13, 1, '3c7tqjgap8chce3hae56fil91g', '::1', '2024-11-12 10:58:51', 1),
(14, 1, '3c7tqjgap8chce3hae56fil91g', '::1', '2024-11-12 13:01:14', 1),
(15, 1, '3c7tqjgap8chce3hae56fil91g', '::1', '2024-11-12 13:10:19', 1),
(16, 1, 's4olufl738mku4cg1o5dt4icep', '::1', '2024-11-13 11:32:42', 1),
(17, 1, 's4olufl738mku4cg1o5dt4icep', '::1', '2024-11-13 14:20:00', 1),
(18, 1, 'pqt6c7aonvvgacmn124hhh87an', '::1', '2024-11-14 11:01:51', 1),
(19, 1, 'j913noqgbqsemijg0g18qt6362', '::1', '2024-11-14 17:43:45', 1),
(20, 2, 'fq4huhu8k8f3c32qjv16a14bei', '::1', '2024-11-15 11:04:02', 1),
(21, 1, 'fq4huhu8k8f3c32qjv16a14bei', '::1', '2024-11-15 13:06:49', 1),
(22, 1, 'fq4huhu8k8f3c32qjv16a14bei', '::1', '2024-11-15 16:34:09', 1),
(23, 1, 'fq4huhu8k8f3c32qjv16a14bei', '::1', '2024-11-15 17:41:40', 1),
(24, 1, 'fq4huhu8k8f3c32qjv16a14bei', '::1', '2024-11-15 19:25:16', 1),
(25, 1, 'fq4huhu8k8f3c32qjv16a14bei', '::1', '2024-11-15 20:30:03', 1),
(26, 1, 'o6gdr9fdf00hlun4t1c6n9ouuo', '::1', '2024-11-16 11:29:42', 1),
(27, 1, 'o6gdr9fdf00hlun4t1c6n9ouuo', '::1', '2024-11-16 11:45:24', 1),
(28, 1, 'o6gdr9fdf00hlun4t1c6n9ouuo', '::1', '2024-11-16 13:51:25', 1),
(29, 1, 'o6gdr9fdf00hlun4t1c6n9ouuo', '::1', '2024-11-16 14:24:55', 1),
(30, 1, 'o6gdr9fdf00hlun4t1c6n9ouuo', '::1', '2024-11-16 14:38:20', 1),
(31, 1, 'o6gdr9fdf00hlun4t1c6n9ouuo', '::1', '2024-11-16 14:39:33', 1),
(32, 1, 'o6gdr9fdf00hlun4t1c6n9ouuo', '::1', '2024-11-16 14:41:35', 1),
(33, 1, '76b441u9qbeu218duq0q9fl4ea', '::1', '2024-11-18 12:36:08', 1),
(34, 1, '76b441u9qbeu218duq0q9fl4ea', '::1', '2024-11-18 12:36:57', 1),
(35, 1, '76b441u9qbeu218duq0q9fl4ea', '::1', '2024-11-18 13:14:05', 1),
(36, 1, 'i3m92endq5bv2seu4un6vlhlle', '::1', '2024-11-19 10:43:23', 1),
(37, 1, 'fs1ce5739kf27osisdkqahpiie', '::1', '2024-11-20 12:19:51', 1),
(38, 1, 'il6ca3fr6bok30r8a5h6mg026e', '::1', '2024-11-21 10:22:59', 1),
(39, 1, 'il6ca3fr6bok30r8a5h6mg026e', '::1', '2024-11-21 11:03:32', 1),
(40, 1, 'il6ca3fr6bok30r8a5h6mg026e', '::1', '2024-11-21 11:08:49', 1),
(41, 1, 'c5lkhfgp7if3nvhkaei5dk8dg5', '::1', '2024-11-22 12:55:28', 1),
(42, 1, '9dg2984o0sut93i5molkgst8uo', '::1', '2024-11-25 11:34:57', 1),
(43, 1, 't23nuor8vc6us8v0s00dac1a7j', '::1', '2024-11-26 10:59:31', 1),
(44, 2, '3l7hl6r9n0ct9hr05qfiivtj5u', '::1', '2024-11-26 20:07:42', 1),
(45, 1, 'f8mui80of376h7543eo53o4qkp', '::1', '2024-11-27 11:27:52', 1),
(46, 1, 'f8mui80of376h7543eo53o4qkp', '::1', '2024-11-27 11:28:21', 1),
(47, 2, 'ft2iqqn53tnambjjg8ff30mprf', '::1', '2024-11-27 15:21:41', 1),
(48, 3, 'psveesneldedgsocvv02jjcklq', '127.0.0.1', '2024-11-27 15:40:03', 1),
(49, 1, '081mh2uibggpr1jvutqfnhibbj', '::1', '2024-11-28 11:20:47', 1),
(50, 1, '081mh2uibggpr1jvutqfnhibbj', '::1', '2024-11-28 11:21:26', 1),
(51, 1, '081mh2uibggpr1jvutqfnhibbj', '::1', '2024-11-28 11:21:43', 1),
(52, 1, '1tu6an0ee9ubosjij0hvsaaet7', '::1', '2024-11-28 14:35:03', 1),
(53, 1, '1hr5vpv8182aiu7jaktv1i8dd6', '::1', '2024-11-29 12:58:33', 1),
(54, 2, '6nvu4h5m6lv9leo72ht8uqdgfe', '::1', '2024-11-29 18:16:35', 1),
(55, 1, 'mpgjo06orid010e4qd5in1m0ai', '::1', '2024-11-30 12:33:37', 1),
(56, 1, 'eqaegsp791ltcjis6pn1sroufh', '::1', '2024-12-02 11:43:24', 1),
(57, 1, 'b589at777gr76cfj69fji4f7mu', '::1', '2024-12-03 11:36:44', 1),
(58, 1, '6pn0fmut3b70gbdgi819nl8jmu', '::1', '2024-12-04 11:08:13', 1),
(59, 2, 'er2d7v6qjt2joaf33ig7lvo9fc', '::1', '2024-12-04 15:17:45', 1),
(60, 3, 'lumlvt71udd9o8vmkqvtnak0f9', '127.0.0.1', '2024-12-04 17:41:35', 1),
(61, 1, 'fbbpjmtckouak178ada50m34qc', '::1', '2024-12-05 11:27:15', 1),
(62, 2, '4df24uqlqar0bvmcirfm2dhu3j', '127.0.0.1', '2024-12-05 11:37:44', 1),
(63, 1, 'k18f5to3v6konfp6i0lum8399v', '::1', '2024-12-06 10:27:49', 1),
(64, 2, '1cf1jf52fsrns2981up3rnuhvj', '::1', '2024-12-06 12:09:38', 1),
(65, 4, 'crr3235lemucqgm7eb65atnbse', '127.0.0.1', '2024-12-06 13:54:39', 1),
(66, 4, 'crr3235lemucqgm7eb65atnbse', '127.0.0.1', '2024-12-06 13:55:00', 1),
(67, 1, 'l9ahknpjr3oc5s7d9j2c9tq49t', '::1', '2024-12-09 11:23:31', 1),
(68, 1, 'l9ahknpjr3oc5s7d9j2c9tq49t', '::1', '2024-12-09 11:30:33', 1),
(69, 2, 'gck3gqufsevoasbjgsn9a6rhsg', '::1', '2024-12-09 11:31:18', 1),
(70, 7, '1aei113aqpo7cg3uqi4e7d2b2v', '127.0.0.1', '2024-12-09 13:03:25', 1),
(71, 4, 'surm833ncq19kt5g2p9qaspi8t', '127.0.0.1', '2024-12-09 17:55:38', 1),
(72, 1, '0tk5l02vg0avlkpql2sq6smrrq', '::1', '2024-12-10 11:04:45', 1),
(73, 2, 'j0tpjphr7rok8i7m3p1tpdhatm', '::1', '2024-12-10 11:32:35', 1),
(74, 4, 'ea66h189ctvnebhnbs3afoidpi', '127.0.0.1', '2024-12-10 11:48:56', 1),
(75, 1, 'l51s99ajh22jriqim75v2hdta5', '::1', '2024-12-11 11:26:39', 1),
(76, 2, 'n1pujdglolqvp87idouftugb01', '::1', '2024-12-11 16:12:18', 1),
(77, 7, '51ka95o81j4lfhurhvl7v3ucrl', '127.0.0.1', '2024-12-11 16:42:50', 1),
(78, 1, '2qn4hhn9oaus9pcgj6inc2bie5', '::1', '2024-12-12 11:12:07', 1),
(79, 3, 'm4ld1dqa9km8edi7mioavvq2qg', '::1', '2024-12-12 11:58:15', 1),
(80, 2, '2bjtq2hpesqak5b9fe4mh1duql', '127.0.0.1', '2024-12-12 12:32:33', 1),
(81, 1, '2qn4hhn9oaus9pcgj6inc2bie5', '::1', '2024-12-12 13:37:45', 1),
(82, 1, '2qn4hhn9oaus9pcgj6inc2bie5', '::1', '2024-12-12 15:16:53', 1),
(83, 1, '0aad0gqed6qetiabmvpmdpcc3u', '::1', '2024-12-13 12:09:12', 1),
(84, 8, '7m53oedv64b46srq6l29ehgjs9', '::1', '2024-12-13 12:35:06', 1),
(85, 8, '7m53oedv64b46srq6l29ehgjs9', '::1', '2024-12-13 12:35:24', 1),
(86, 1, 'f9kofvi80osfgmtqv6pbrf531a', '::1', '2024-12-16 11:02:55', 1),
(87, 1, 'p3grr93v6kdrs880kngfmhfuq2', '::1', '2024-12-18 14:47:35', 1),
(88, 1, '727l731daoliq0m35p71j6fu9b', '::1', '2024-12-19 11:35:26', 1),
(89, 1, '5jitg70f1audgi9g8r4q2bk3f7', '::1', '2024-12-20 11:53:51', 1),
(90, 1, 'up57gl7c5s1ho1gjl50oubc9mi', '::1', '2024-12-20 22:17:14', 1),
(91, 2, 't26gihf37ufjtd962s2u5r05q0', '::1', '2024-12-20 22:21:20', 1),
(92, 1, 'up57gl7c5s1ho1gjl50oubc9mi', '::1', '2024-12-21 12:24:06', 1),
(93, 1, 'up57gl7c5s1ho1gjl50oubc9mi', '::1', '2024-12-21 12:24:46', 1),
(94, 1, 'up57gl7c5s1ho1gjl50oubc9mi', '::1', '2024-12-21 15:51:05', 1),
(95, 1, '7197rbmucsk1b5kqmdfvjvlnuj', '::1', '2024-12-23 10:40:27', 1),
(96, 1, '7197rbmucsk1b5kqmdfvjvlnuj', '::1', '2024-12-23 13:45:55', 1),
(97, 1, '7197rbmucsk1b5kqmdfvjvlnuj', '::1', '2024-12-23 15:05:50', 1),
(98, 2, '3lqfo4j3hj2mp2rnplbvvtp5nj', '::1', '2024-12-23 15:16:58', 1),
(99, 1, '7197rbmucsk1b5kqmdfvjvlnuj', '::1', '2024-12-23 17:07:37', 1),
(100, 1, 'ekppehk0fdosvkse3lt1ppnrra', '::1', '2024-12-24 11:28:24', 1),
(101, 2, 'c71b7etf0brj2jq0o6haojd40p', '::1', '2024-12-24 11:36:30', 1),
(102, 1, 'cskn9oshdrg3qkt6t6qr529hkq', '::1', '2024-12-25 11:48:26', 1),
(103, 4, 'v99sluoidjdpso5grbnbd9sn9s', '::1', '2024-12-25 12:47:32', 1),
(104, 4, 'v99sluoidjdpso5grbnbd9sn9s', '::1', '2024-12-25 12:47:43', 1),
(105, 4, 'v99sluoidjdpso5grbnbd9sn9s', '::1', '2024-12-25 12:48:52', 1),
(106, 4, 'v99sluoidjdpso5grbnbd9sn9s', '::1', '2024-12-25 12:49:24', 1),
(107, 4, 'v99sluoidjdpso5grbnbd9sn9s', '::1', '2024-12-25 13:05:38', 1),
(108, 2, '7l6go9qhd5urgvhmcil84mac7t', '127.0.0.1', '2024-12-25 13:29:23', 1),
(109, 1, 'si8gdvfa99pp35cd7houtmlcs3', '::1', '2024-12-26 14:26:38', 1),
(110, 2, '6lakkvb5fidd75t0mg5r14f4vc', '::1', '2024-12-26 16:33:44', 1),
(111, 1, '9k7t2f3pnnp6qttl7906qlf4o0', '::1', '2024-12-27 10:59:39', 1),
(112, 4, '4auuj2ec044k52877cf2j6nkdq', '::1', '2024-12-27 12:15:28', 1),
(113, 1, '9k7t2f3pnnp6qttl7906qlf4o0', '::1', '2024-12-27 15:13:00', 1),
(114, 2, '4auuj2ec044k52877cf2j6nkdq', '::1', '2024-12-27 16:15:08', 1),
(115, 5, 'rjqhv2nok4pi5ottdgd8mkv5ce', '127.0.0.1', '2024-12-27 16:56:57', 1),
(116, 4, 'rjqhv2nok4pi5ottdgd8mkv5ce', '127.0.0.1', '2024-12-27 17:24:08', 1),
(117, 1, 'gk2s6kl8q579cajfsrdtd86poh', '::1', '2024-12-30 10:49:59', 1),
(118, 4, '1p4m2ig3cgl7c06kjjjgfhkecv', '::1', '2024-12-30 12:32:19', 1),
(119, 1, 'e84ftm68rujuu8tb0e4jfkh7q4', '::1', '2024-12-31 11:14:08', 1),
(120, 2, 's986mi3j8sflk81dn4qlt3gt9u', '::1', '2024-12-31 12:20:15', 1),
(121, 7, 'flc3r9g0sb4g23q2ff89rp6p14', '127.0.0.1', '2024-12-31 16:06:12', 1),
(122, 1, 'u5ruofsid2l64g0kr1odnsvvb7', '::1', '2024-12-31 17:52:40', 1),
(123, 1, 'nnmogo4tv9ibnnere6jtpv0hcp', '::1', '2025-01-09 11:17:24', 1),
(124, 1, '2h7qt54re4ictbfgm8ds28grji', '127.0.0.1', '2025-01-09 15:19:35', 1),
(125, 1, '5angohss1rasp1vo8bvcnftl4c', '::1', '2025-01-09 17:44:19', 1),
(126, 1, 's1r7kt58d5splf1ih5qqunbh9c', '::1', '2025-01-10 11:00:08', 1),
(127, 2, 'mqjpt693mihvtbupbmbo103192', '::1', '2025-01-10 17:25:48', 1),
(128, 1, '637jntuqg4dsjabvo2rdfkr8fo', '::1', '2025-01-11 11:32:18', 1),
(129, 1, 'sklfvc2u5pbfd7v7kcgckebr4t', '::1', '2025-01-11 13:08:36', 1),
(130, 1, 'bns78bebt0pvnpn4kcg2128mbp', '::1', '2025-01-31 12:07:03', 1),
(131, 1, 'q8jo5ue6hdl3715r967lag0p5j', '127.0.0.1', '2025-04-15 10:27:30', 1),
(132, 1, 'q8jo5ue6hdl3715r967lag0p5j', '127.0.0.1', '2025-04-15 11:57:04', 1),
(133, 1, '1jvgte7uif3h70o9hp6t6cdmu2', '::1', '2025-04-28 19:08:24', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `coid` int(11) NOT NULL,
  `usertype` int(11) NOT NULL,
  `userteam` int(11) DEFAULT NULL,
  `userstatus` longtext DEFAULT NULL,
  `userempid` varchar(255) NOT NULL,
  `userpassword` varchar(255) NOT NULL,
  `useremailid` varchar(255) NOT NULL,
  `userfirstname` varchar(255) NOT NULL,
  `userlastname` varchar(255) NOT NULL,
  `usercontactno` varchar(255) NOT NULL,
  `useraddressline1` longtext NOT NULL,
  `useraddressline2` varchar(255) DEFAULT NULL,
  `usercity` varchar(255) DEFAULT NULL,
  `stid` int(11) NOT NULL,
  `userzipcode` longtext NOT NULL,
  `userdob` date NOT NULL,
  `userdateofjoining` date DEFAULT NULL,
  `userpic` longtext DEFAULT NULL,
  `usercasualleave` varchar(15) DEFAULT NULL,
  `usercompleave` varchar(15) DEFAULT NULL,
  `usersickleave` varchar(15) DEFAULT NULL,
  `usermaternityleave` varchar(15) DEFAULT NULL,
  `createby` int(11) NOT NULL,
  `createdate` datetime NOT NULL,
  `modifyby` int(11) DEFAULT NULL,
  `modifydate` datetime DEFAULT NULL,
  `deletedby` int(11) DEFAULT NULL,
  `deleteddate` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL,
  `userlogintime` datetime DEFAULT NULL,
  `userloginip` longtext DEFAULT NULL,
  `permission` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `coid`, `usertype`, `userteam`, `userstatus`, `userempid`, `userpassword`, `useremailid`, `userfirstname`, `userlastname`, `usercontactno`, `useraddressline1`, `useraddressline2`, `usercity`, `stid`, `userzipcode`, `userdob`, `userdateofjoining`, `userpic`, `usercasualleave`, `usercompleave`, `usersickleave`, `usermaternityleave`, `createby`, `createdate`, `modifyby`, `modifydate`, `deletedby`, `deleteddate`, `active`, `userlogintime`, `userloginip`, `permission`) VALUES
(1, 1, 1, NULL, NULL, '', 'admin', 'sumit.satva@gmail.com', 'Sumit', 'Mittal', '9377327530', 'E-308, Titanium City Center,', '100ft Anand Nagar Road, Satellite', 'Ahmedabad', 12, '380015', '2024-11-11', '2024-11-12', NULL, NULL, NULL, NULL, NULL, 1, '2024-11-11 08:21:39', 1, '2024-11-12 17:59:51', NULL, NULL, 1, NULL, NULL, NULL),
(2, 1, 3, NULL, 'Permanent', '1', 'mukesh123', 'mukesh.satva@gmail.com', 'Mukesh', 'Yadav', '9904870129', 'E-308. Titanium CIty Center,', '', 'Ahmedabad', 12, '', '2024-11-20', '2024-11-20', 'greenhill_logo.jpeg', '15', '2', '10', '182', 1, '2024-11-20 19:04:01', 1, '2024-12-03 12:04:28', NULL, NULL, 1, NULL, NULL, NULL),
(3, 1, 3, NULL, 'Permanent', '2', 'aron123', 'aron@gmail.com', 'Aron', 'Smith', '9904870123', 'aaaa', '', 'aaaaa', 11, '', '2024-11-27', '2024-11-27', 'greenhill_logo.jpeg', '15', '2', '10', '182', 1, '2024-11-27 15:39:34', 1, '2024-12-03 12:04:44', NULL, NULL, 1, NULL, NULL, NULL),
(4, 1, 4, 2, 'Permanent', '3', 'TM1', 'TM1@gmail.com', 'TM1', 'TM1', '123456', 'TM1', '', 'TM1', 15, '', '2024-11-27', '2024-11-27', 'greenhill_logo.jpeg', '15', '2', '10', '182', 1, '2024-11-27 16:00:08', 1, '2024-12-03 12:27:20', NULL, NULL, 1, NULL, NULL, NULL),
(5, 1, 4, 4, 'Probation', '4', 'TM2', 'TM2@gmail.com', 'TM2', 'TM2', '123456', 'TM2', '', 'TM2', 8, '', '2024-11-27', '2024-11-27', 'greenhill_logo.jpeg', '0', '0', '0', '0', 1, '2024-11-27 16:00:42', 1, '2024-12-27 16:58:52', NULL, NULL, 1, NULL, NULL, NULL),
(6, 1, 5, 4, 'Permanent', '4', 'TM3', 'TM3@gmail.com', 'TM3', 'TM3', '123456', 'TM3', '', 'TM3', 8, '', '2024-11-27', '2024-11-27', 'greenhill_logo.jpeg', '15', '2', '10', '182', 1, '2024-11-27 16:00:42', 1, '2024-12-27 17:05:49', NULL, NULL, 1, NULL, NULL, NULL),
(7, 1, 2, 0, 'Permanent', '5', 'bd123', 'tl1@gmail.com', 'bd1', 'bd1', '9876543210', 'E-308, Titanium City Center', 'Iscon', 'Ahmedabad', 12, '380004', '2024-12-09', '2024-12-09', 'greenhill_logo.jpeg', '15', '2', '10', '182', 1, '2024-12-09 13:01:26', 1, '2024-12-31 16:04:55', NULL, NULL, 1, NULL, NULL, NULL),
(8, 1, 3, 0, 'Permanent', '6', 'tl123', 'tl2@gmail.com', 'TL1', 'tl1', '987654321', 'Titanium city center', 'iscon', 'Ahmedabad', 12, '123212', '2024-12-12', '2024-12-12', 'greenhill_logo.jpeg', '15', '2', '10', '182', 1, '2024-12-12 12:19:00', 1, '2024-12-12 12:19:00', NULL, NULL, 1, NULL, NULL, NULL),
(9, 1, 5, 4, 'Permanent', '7', '123', 'new@gmail.com', 'TM', 'NEW', '+919904870239', 'Titanium CIty Center', 'Iscon', 'AHmedabad', 12, '3809201', '2024-12-27', '2024-12-27', 'greenhill_logo.jpeg', '15', '2', '10', '182', 1, '2024-12-27 17:22:47', 1, '2024-12-27 17:22:47', NULL, NULL, 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `usertypes`
--

CREATE TABLE `usertypes` (
  `usertypeid` int(11) NOT NULL,
  `usertype` varchar(255) NOT NULL,
  `createby` int(11) NOT NULL,
  `createdate` datetime DEFAULT NULL,
  `modifyby` int(11) DEFAULT NULL,
  `modifydate` datetime DEFAULT NULL,
  `deleteby` int(11) DEFAULT NULL,
  `deletedate` datetime DEFAULT NULL,
  `active` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `usertypes`
--

INSERT INTO `usertypes` (`usertypeid`, `usertype`, `createby`, `createdate`, `modifyby`, `modifydate`, `deleteby`, `deletedate`, `active`) VALUES
(1, 'Admin', 1, '2024-11-08 16:09:52', 1, '2024-11-11 13:25:06', NULL, NULL, 1),
(2, 'BD', 1, '2024-11-08 16:09:59', 1, '2024-11-12 11:12:18', NULL, NULL, 1),
(3, 'TL Head', 1, '2024-11-11 13:20:08', 1, '2024-12-31 14:20:48', NULL, NULL, 1),
(4, 'Tl', 1, '2024-11-12 11:12:01', 1, '2024-12-31 14:20:53', NULL, NULL, 1),
(5, 'TM', 1, '2024-11-12 11:12:40', 1, '2024-12-23 17:52:21', NULL, NULL, 1),
(6, 'Research', 1, '2024-12-23 17:52:24', 1, '2024-12-23 17:52:24', NULL, NULL, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`coid`);

--
-- Indexes for table `holidays`
--
ALTER TABLE `holidays`
  ADD PRIMARY KEY (`hid`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`),
  ADD KEY `coid` (`coid`);

--
-- Indexes for table `usertypes`
--
ALTER TABLE `usertypes`
  ADD PRIMARY KEY (`usertypeid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `coid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `holidays`
--
ALTER TABLE `holidays`
  MODIFY `hid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sessions`
--
ALTER TABLE `sessions`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=134;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `usertypes`
--
ALTER TABLE `usertypes`
  MODIFY `usertypeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
