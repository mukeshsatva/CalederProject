<?php
// Not is use
function getFullName($con, $UserId)
{
    $result_get_name = mysqli_query($con, "select CONCAT(UserFirstName, ' ', userlastname) as fullname from users where UserId='$UserId'") or die(mysqli_error($con));
    $row_get_name = mysqli_fetch_assoc($result_get_name);
    return $row_get_name['fullname'];
}


function GetHolidayList()
{
    include('connect.php');
    $holidays = array();
    $result = mysqli_query($con, "SELECT hdate  FROM holidays  where active !='2' AND YEAR(hdate) = YEAR(CURDATE()) order by hid asc") or die(mysqli_error($con));
    while ($row = mysqli_fetch_assoc($result)) {
        $holidays[] = date('d-M-y', strtotime($row['hdate']));
    }
    return $holidays;
}


function getAging($startDate, $endDate)
{
    $excludedDates = GetHolidayList();
    // Create DateTime objects from the input dates
    $start = DateTime::createFromFormat('d-m-Y', $startDate);
    $end = new DateTime($endDate);
    // Ensure the end date is greater than the start date
    if ($start > $end) {
        return "End date must be greater than start date.";
    }
    // Initialize the business days counter
    $businessDays = 0;  
    // Convert excluded dates to DateTime objects for easier comparison
    $excludedDateTimes = array_map(function ($date) {
        return DateTime::createFromFormat('d-M-y', $date); // Use 'd-M-y' for the format
    }, $excludedDates);
    // Loop through each day between the start and end dates
    while ($start <= $end) {
        // Check if the current day is a weekday (Monday to Friday)
        // and not in the excluded dates
        if ($start->format('N') < 6 && !in_array($start->format('Y-m-d'), array_map(function ($dt) {
            return $dt->format('Y-m-d');
        }, $excludedDateTimes))) {
            $businessDays++;
        }
        // Move to the next day
        $start->modify('+1 day');
    }
    return $businessDays;
}

// Back to work date.
function getTargetDate($startDate, $numDays) {
    $excludedDates = GetHolidayList(); // Fetch holidays
    $start = DateTime::createFromFormat('d-m-Y', $startDate);
    
    if (!$start) {
        return "Invalid start date format. Use 'd-m-Y'.";
    }

    $excludedDateTimes = array_map(function ($date) {
        return DateTime::createFromFormat('d-M-y', $date);
    }, $excludedDates);

    $workingDaysCount = 0;

    while ($workingDaysCount < $numDays) {
        $start->modify('+1 day');

        // Check if it's a weekday and not a holiday
        if ($start->format('N') < 6 && !in_array($start->format('Y-m-d'), array_map(function ($dt) {
            return $dt->format('Y-m-d');
        }, $excludedDateTimes))) {
            $workingDaysCount++;
        }
    }

    return $start->format('d-m-Y'); // Return the final target date
}


// Bussiness Days
function getBusinessDaysDifference($startDate, $endDate)
{
    $start = DateTime::createFromFormat('d-m-Y', $startDate);
    $end = DateTime::createFromFormat('d-m-Y', $endDate);

    if ($start > $end) {
        return "End date must be greater than start date.";
    }

    $businessDays = 0;

    while ($start <= $end) {
        if ($start->format('N') < 6) {
            $businessDays++;
        }
        $start->modify('+1 day');
    }

    return $businessDays;
}


// Aging Calculation Old
function getAging_old($startDate, $endDate)
{
    $start = new DateTime($startDate);
    $end = new DateTime($endDate);
    $interval = $start->diff($end);
    $aging = '';
    if ($interval->y > 0) {
        $aging .= $interval->y . ' years ';
    }
    if ($interval->m > 0) {
        $aging .= $interval->m . ' months ';
    }
    if ($interval->d > 0) {
        $aging .= $interval->d . ' days ';
    }
    $aging = trim($aging);
    if (empty($aging)) {
        $aging = '0 days';
    }
    return $aging;
}

// Image AND PDF Upload Only
function handleFileUploadimageANDpdf($file, $target_dir, $id)
{
    $uploadOk = 1;

    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $target_file = $target_dir . $id . "_" . basename($file["name"]);
    $fileExtension = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    $allowedMimeTypes = ['image/jpeg', 'image/png', 'application/pdf'];
    $allowedExtensions = ['jpg', 'jpeg', 'png', 'pdf'];

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file["tmp_name"]);
    finfo_close($finfo);

    if (!in_array($mimeType, $allowedMimeTypes) || !in_array($fileExtension, $allowedExtensions)) {
        $errortype = "notallowed";
        $uploadOk = 0;
        return ["errortype" => $errortype, "uploadOk" => $uploadOk];
    }

    $maxSize = 5 * 1024 * 1024; // 5 MB in bytes
    if ($file["size"] > $maxSize) {
        $errortype = "filetoolarge";
        $uploadOk = 0;
        return ["errortype" => $errortype, "uploadOk" => $uploadOk];
    }

    if ($uploadOk == 0) {
        $errortype = "notuploaded";
        return ["errortype" => $errortype, "uploadOk" => $uploadOk];
    } else {
        move_uploaded_file($file["tmp_name"], $target_file);
        return ["uploadOk" => $uploadOk];
    }
}
// Image Upload Only
function handleFileUploadimage($file, $target_dir, $id)
{
    $uploadOk = 1;

    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $target_file = $target_dir . $id . "_" . basename($file["name"]);
    $fileExtension = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    $allowedMimeTypes = ['image/jpeg', 'image/png'];
    $allowedExtensions = ['jpg', 'jpeg', 'png'];

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file["tmp_name"]);
    finfo_close($finfo);

    if (!in_array($mimeType, $allowedMimeTypes) || !in_array($fileExtension, $allowedExtensions)) {
        $errortype = "notallowed";
        $uploadOk = 0;
        return ["errortype" => $errortype, "uploadOk" => $uploadOk];
    }

    $maxSize = 5 * 1024 * 1024; // 5 MB in bytes
    if ($file["size"] > $maxSize) {
        $errortype = "filetoolarge";
        $uploadOk = 0;
        return ["errortype" => $errortype, "uploadOk" => $uploadOk];
    }

    if ($uploadOk == 0) {
        $errortype = "notuploaded";
        return ["errortype" => $errortype, "uploadOk" => $uploadOk];
    } else {
        move_uploaded_file($file["tmp_name"], $target_file);
        return ["uploadOk" => $uploadOk];
    }
}


// File PDF and Words Upload
function handleFileUpload($file, $target_dir, $id)
{
    $uploadOk = 1;

    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $target_file = $target_dir . $id . "_" . basename($file["name"]);
    $fileExtension = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    $allowedMimeTypes = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];

    $allowedExtensions = ['pdf', 'doc', 'docx'];

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file["tmp_name"]);
    finfo_close($finfo);

    if (!in_array($mimeType, $allowedMimeTypes) || !in_array($fileExtension, $allowedExtensions)) {
        $errortype = "notallowed";
        $uploadOk = 0;
        return ["errortype" => $errortype, "uploadOk" => $uploadOk];
    }

    if ($uploadOk == 0) {
        $errortype = "notuploaded";
        return ["errortype" => $errortype, "uploadOk" => $uploadOk];
    } else {
        move_uploaded_file($file["tmp_name"], $target_file);
        return ["uploadOk" => $uploadOk];
    }
}


// File PDF and Words Upload But Extra Extesions
function handleFileUploadResume($file, $target_dir, $id)
{
    $uploadOk = 1;

    // Create directory if it doesn't exist
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $target_file = $target_dir . $id . "_" . basename($file["name"]);
    $fileExtension = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check MIME type for allowed file types (PDF, DOC, DOCX)
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file["tmp_name"]);
    finfo_close($finfo);

    $allowedMimeTypes = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-word.document.12',
        'application/vnd.oasis.opendocument.text',
        'application/vnd.ms-word',
        'application/vnd.ms-word.document.macroEnabled.12',
        'application/vnd.ms-word.template.macroEnabled.12',
        'application/vnd.wordperfect'
    ];

    $allowedExtensions = ['pdf', 'doc', 'docx', 'odt', 'rtf', 'txt', 'wpd'];

    // Check file extension
    if (!in_array($fileExtension, $allowedExtensions)) {
        $errortype = "notallowedcv";
        $uploadOk = 0;
        return ["errortype" => $errortype, "uploadOk" => $uploadOk];
    }

    // Check file size: Minimum 50 KB, Maximum 5 MB
    $minSize = 50 * 1024; // 50 KB in bytes
    $maxSize = 5 * 1024 * 1024; // 5 MB in bytes

    // if ($file["size"] < $minSize) {
    //     $errortype = "filetoosmall";
    //     $uploadOk = 0;
    //     return ["errortype" => $errortype, "uploadOk" => $uploadOk];
    // }

    if ($file["size"] > $maxSize) {
        $errortype = "filetoolarge";
        $uploadOk = 0;
        return ["errortype" => $errortype, "uploadOk" => $uploadOk];
    }

    // Attempt to upload the file
    if ($uploadOk == 0) {
        $errortype = "notuploaded";
        return ["errortype" => $errortype, "uploadOk" => $uploadOk];
    } else {
        if (move_uploaded_file($file["tmp_name"], $target_file)) {
            return ["uploadOk" => $uploadOk, "filename" => $target_file];
        } else {
            $errortype = "uploaderror";
            $uploadOk = 0;
            return ["errortype" => $errortype, "uploadOk" => $uploadOk];
        }
    }
}

// PDF ONLY
// function handleFileUploadPDF($file, $target_dir, $id)
// {
//     $uploadOk = 1;

//     if (!is_dir($target_dir)) {
//         mkdir($target_dir, 0777, true);
//     }

//     $target_file = $target_dir . $id . "_" . basename($file["name"]);
//     $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

//     // Check if file is a PDF using MIME type
//     $finfo = finfo_open(FILEINFO_MIME_TYPE);
//     $mimeType = finfo_file($finfo, $file["tmp_name"]);
//     finfo_close($finfo);

//     // Allow PDF file only
//     if ($mimeType === 'application/pdf') {
//         $uploadOk = 1;
//     } else {
//         $errortype = "notapdf";
//         $uploadOk = 0;
//         return ["errortype" => $errortype, "uploadOk" => $uploadOk];
//     }

//     // Allow certain size of file
//     if ($file["size"] > 5 * 1024 * 1024) { // 5 MB in bytes
//         $errortype = "filetoolarge";
//         $uploadOk = 0;
//         return ["errortype" => $errortype, "uploadOk" => $uploadOk];
//     }

//     // Allow certain file formats (extension check)
//     if ($imageFileType !== "pdf") {
//         $errortype = "notallowed";
//         $uploadOk = 0;
//         return ["errortype" => $errortype, "uploadOk" => $uploadOk];
//     }

//     if ($uploadOk == 0) {
//         $errortype = "notuploaded";
//         return ["errortype" => $errortype, "uploadOk" => $uploadOk];
//     } else {
//         move_uploaded_file($file["tmp_name"], $target_file);
//         return ["uploadOk" => $uploadOk];
//     }
// }

// Saving Image From URL
function saveImageFromUrl($imageUrl)
{
    $response = ['code' => 0, 'message' => ''];

    if (filter_var($imageUrl, FILTER_VALIDATE_URL)) {
        $headers = get_headers($imageUrl, 1);
        $contentType = isset($headers['Content-Type']) ? $headers['Content-Type'] : $headers['content-type'];

        if (is_array($contentType)) {
            $contentType = $contentType[0];
        }

        if (strpos($contentType, 'image/') === 0 || $contentType === 'binary/octet-stream') {
            $imageContent = file_get_contents($imageUrl);
            if ($imageContent !== false) {
                $imageName = basename($imageUrl);
                $imagebase64 = base64_encode($imageContent);

                if ($contentType === 'binary/octet-stream') {
                    $ext = pathinfo($imageName, PATHINFO_EXTENSION);
                    if (empty($ext)) {
                        $imageType = exif_imagetype($imageUrl);
                        $ext = image_type_to_extension($imageType, false);
                        $imageName .= ".$ext";
                    }
                }

                // $saveFolder = rtrim($saveFolder, '/') . '/' . $bid . '/';

                // if (!is_dir($saveFolder)) {
                //     mkdir($saveFolder, 0777, true);
                // }

                // $savePath = $saveFolder . $bid . '_' . $imageName;

                // if (file_put_contents($savePath, $imageContent)) {
                if ($imagebase64 != false) {
                    $response['code'] = 1;
                    $response['message'] = $imagebase64;
                } else {
                    $response['message'] = "Failed to save the image.";
                }
            } else {
                $response['message'] = "Could not download the image from the provided URL.";
            }
        } else {
            $response['message'] = "The URL does not point to a valid image.";
        }
    } else {
        $response['message'] = "The URL is not valid.";
    }

    return $response;
}

// Slugify
function slugify($string)
{
    // $string = utf8_encode($string);
    $string = mb_convert_encoding($string, 'UTF-8', 'ISO-8859-1');
    $string = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
    $string = preg_replace('/[^a-z0-9- ]/i', '', $string);
    $string = str_replace(' ', '-', $string);
    $string = trim($string, '-');
    $string = strtolower($string);

    if (empty($string)) {
        return 'n-a';
    }
    return $string;
}


// Credentials Mail Sender
function sendLoginCredentials($sendto, $email, $password)
{
    $emailSubject = "Your Login Credentials for Calendar Test";
    $mailBody = "<!DOCTYPE html>
                        <html>
                        <head><title>Calendar Test</title></head>
                        <body style='font-family: Helvetica, Arial, sans-serif; background-color: #f6f6f6; margin: 0; padding: 20px;'>
                            <table
                                style='max-width: 600px; margin: auto; background: #ffffff; border: 3px solid #4fc6e1; border-radius: 7px; padding: 30px;'>
                                <tr>
                                    <td style='text-align: center;'>
                                        <img src='https://transdirectory.in/ghconsultancy/images/logo-wide.png' height='24' alt='logo'>
                                    </td>
                                </tr>
                                <tr>
                                    <td><p>Dear $sendto,</p></td>
                                </tr>
                                <tr>
                                    <td><p>Welcome to <b>Calendar Test</b>! Your account has been successfully created. Below are
                                            your login credentials:</p></td>
                                </tr>
                                <tr><td><b>Email: </b> $email</td></tr>
                                <tr><td><b>Password: </b>$password</td></tr>
                                <tr>
                                    <td style='text-align: center;'>
                                        <a href='https://transdirectory.in/ghconsultancy/' style='background-color: #6658dd; color: #ffffff; padding: 10px 20px; border-radius: 5px; text-decoration: none; font-weight: bold;'>Login</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td style='text-align: center;'>
                                        <p>If you did not request this account or believe this email was sent in error, please contact us
                                            immediately at <a href='mailto:info@satvatechnology.co.in'>info@satvatechnology.co.in</a>.</p>
                                        <p>Thank you for choosing <b>Calendar Test</b>. We look forward to working with you.</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <p>&mdash; <br /><b>Calendar Test</b> </p>
                                    </td>
                                </tr>
                            </table>
                        </body>

                        </html>";

    $headers = "From: no-reply@satvatechnology.co.in\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

    return mail($email, $emailSubject, $mailBody, $headers);
}
