<?php
include('session.php');
include('lib/connect.php');

date_default_timezone_set("Asia/Kolkata");

?>
<!DOCTYPE html>
<html lang="en" data-menu-color="brand">

<head>
    <meta charset="utf-8" />
    <title>Dashboard :: <?php echo $companyname ?></title>
    <?php include('cssjs.php'); ?>

</head>

<body>

    <!-- Begin page -->
    <div id="wrapper">
        <!-- ========== Menu ========== -->
        <?php include('topleft.php'); ?>
        <!-- ========== Left menu End ========== -->

        <div class="content-page">

            <!-- ========== Topbar Start ========== -->
            <?php include('head.php'); ?>
            <!-- ========== Topbar End ========== -->

            <div class="content">

                <!-- Start Content-->
                <div class="container-fluid">

                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <!-- <div class="page-title-right ">
                                    <form action="#" method="post" enctype="multipart/form-data" class="d-flex align-items-center mb-3">
                                        <div class="input-group input-group-sm">
                                            <input type="text" name="txtmonth" class="form-control border" id="dash-daterange">
                                            <span class="input-group-text bg-blue border-blue text-white">
                                                <i class="mdi mdi-calendar-range"></i>
                                            </span>
                                        </div>
                                        <button type="submit" name="btnsubmit" class="btn btn-blue btn-sm ms-2"><i class="mdi mdi-autorenew"></i></button>
                                    </form>
                                </div> -->
                                <h4 class="page-title">Dashboard</h4>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 col-lg-6">
                            <div class="widget-rounded-circle card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="avatar-lg rounded-circle bg-soft-primary border-primary border">
                                                <i class="fe-heart font-22 avatar-title text-primary"></i>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="text-end">
                                                <h3 class="text-dark mt-1">₹<span data-plugin="counterup"><?php echo (isset($totalsales)) ? $totalsales : 0; ?></span></h3>
                                                <p class="text-muted mb-1 text-truncate">this month's Sales</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 col-lg-6">
                            <div class="widget-rounded-circle card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="avatar-lg rounded-circle bg-soft-success border-success border">
                                                <i class="fe-shopping-cart font-22 avatar-title text-success"></i>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="text-end">
                                                <h3 class="text-dark mt-1">₹<span data-plugin="counterup"><?php echo (isset($totalpurchase)) ? $totalpurchase : 0; ?></span></h3>
                                                <p class="text-muted mb-1 text-truncate">This month's Purchase</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div> <!-- content -->

            <!-- Footer Start -->
            <?php include('footer.php'); ?>
            <!-- end Footer -->

        </div>

        <!-- ============================================================== -->
        <!-- End Page content -->
        <!-- ============================================================== -->

    </div>
    <!-- END wrapper -->



    <?php include('bottom.php'); ?>

    <script src="libs/apexcharts/apexcharts.min.js"></script>
    <script>
        $(document).ready(function() {
            $("#dash-daterange").flatpickr({
                altInput: !0,
                // mode: "range",
                altFormat: "F j, y",
                // defaultDate: "today"
            })
        });
    </script>
    <!-- <script>
        $(document).ready(function() {
            $.ajax({
                url: 'get_sales_data.php',
                type: 'POST',
                data: {
                    financiayear: <php echo $current_finyear; ?>
                },
                dataType: 'json',
                success: function(response) {
                    console.log(response);
                    var data = response;
                    var options = {
                        series: [{
                            name: "Sales",
                            type: "column",
                            data: data.sales
                        }, {
                            name: "Purchases",
                            type: "line",
                            data: data.purchases
                        }],
                        chart: {
                            height: 378,
                            type: "line",
                            offsetY: 10
                        },
                        stroke: {
                            width: [2, 3]
                        },
                        plotOptions: {
                            bar: {
                                columnWidth: "50%"
                            }
                        },
                        colors: ["#f1556c", "#4fc6e1"],
                        dataLabels: {
                            enabled: true,
                            enabledOnSeries: [1]
                        },
                        labels: data.months,
                        xaxis: {
                            type: "category"
                        },
                        legend: {
                            offsetY: 7
                        },
                        grid: {
                            padding: {
                                bottom: 20
                            }
                        },
                        fill: {
                            type: "gradient",
                            gradient: {
                                shade: "light",
                                type: "horizontal",
                                shadeIntensity: 0.25,
                                gradientToColors: undefined,
                                inverseColors: true,
                                opacityFrom: 0.75,
                                opacityTo: 0.75,
                                stops: [0, 0, 0]
                            }
                        },
                        yaxis: [{
                            title: {
                                text: "Amount"
                            }
                        }]
                    };
                    var chart = new ApexCharts(document.querySelector("#sales-analytics"), options);
                    chart.render();
                },
                error: function(xhr, status, error) {
                    console.error('Error fetching data:', error);
                }
            });
        });
    </script> -->
</body>

</html>