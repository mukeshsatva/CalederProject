<?php
$dbHost = 'localhost';
$dbUsername = "root";
$dbPassword = "";
$dbName = "calendarinfo";
// $dbUsername = "transdds_transdirectory";
// $dbPassword = "transdds_transdirectory";
// $dbName = "transdds_transdirectory";

$con = mysqli_connect('localhost', $dbUsername, $dbPassword);
mysqli_select_db($con, $dbName)or die(mysqli_error($con));
?>
