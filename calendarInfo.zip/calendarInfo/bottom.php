<div class="offcanvas offcanvas-end right-bar" tabindex="-1" id="theme-settings-offcanvas">
    <div class="d-flex align-items-center w-100 p-0 offcanvas-header">
        <!-- Nav tabs -->
        <ul class="nav nav-tabs nav-bordered nav-justified w-100" role="tablist">
            <li class="nav-item">
                <a class="nav-link p-0 active rounded-0" data-bs-toggle="tab" href="#chat-tab" role="tab">
                    <i class="mdi mdi-message-text d-block font-22"></i>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link p-0 rounded-0" data-bs-toggle="tab" href="#tasks-tab" role="tab">
                    <i class="mdi mdi-format-list-checkbox d-block font-22"></i>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link p-0 rounded-0" data-bs-toggle="tab" href="#Social-tab" role="tab">
                    <i class="mdi mdi-focus-auto d-block font-22"></i>
                </a>
            </li>
        </ul>
    </div>

    <div class="offcanvas-body p-0 h-100" data-simplebar>
        <!-- Tab panes -->
        <div class="tab-content pt-0">
            <div class="tab-pane active" id="chat-tab" role="tabpanel">

                <form class="search-bar">
                    <div class="position-relative">
                        <input type="text" class="form-control" id="teamSearch" placeholder="Search...">
                        <span class="mdi mdi-magnify"></span>
                    </div>
                </form>

                <h6 class="fw-medium mt-3 text-uppercase">Team <a href="javascript: void(0);" class="font-18 text-danger"></a></h6>


            </div>

            <div class="tab-pane " id="tasks-tab" role="tabpanel">
                <div class="p-3 mt-2 d-grid">
                    <a data-bs-toggle="modal" data-bs-target="#task-modal" class="badge badge-outline-primary rounded-pill waves-effect waves-light"><i class="mdi mdi-pencil"></i> Create Task</a>
                </div>
            </div>

            <div class="tab-pane  text-center" id="Social-tab" role="tabpanel">

            </div>
        </div>
    </div>

    <!-- <div class="offcanvas-footer border-top py-2 px-2 text-center">
        <div class="d-flex gap-2">
            <button type="button" class="btn btn-light w-50" id="reset-layout">Reset</button>
            <a href="https://1.envato.market/uboldadmin" class="btn btn-danger w-50" target="_blank"><i class="mdi mdi-basket me-1"></i> Buy</a>
        </div>
    </div> -->
</div>

<script src="js/vendor.min.js"></script>

<script src="js/app.min.js"></script>

<script src="libs/magnific-popup/jquery.magnific-popup.min.js"></script>

<script src="js/pages/gallery.init.js"></script>
<script src="js/pages/form-wizard.init.js"></script>

<script src="libs/dropzone/min/dropzone.min.js"></script>
<script src="libs/dropify/js/dropify.min.js"></script>

<script src="js/pages/form-fileuploads.init.js"></script>

<script src="libs/flatpickr/flatpickr.min.js"></script>
<script src="js/pages/form-pickers.init.js"></script>

<script src="libs/selectize/js/standalone/selectize.min.js"></script>
<script src="libs/mohithg-switchery/switchery.min.js"></script>
<script src="libs/multiselect/js/jquery.multi-select.js"></script>
<script src="libs/select2/js/select2.min.js"></script>
<script src="libs/devbridge-autocomplete/jquery.autocomplete.min.js"></script>
<script src="libs/bootstrap-maxlength/bootstrap-maxlength.min.js"></script>

<script src="libs/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="libs/datatables.net-bs5/js/dataTables.bootstrap5.min.js"></script>
<script src="libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="libs/datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js"></script>
<script src="libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="libs/datatables.net-buttons-bs5/js/buttons.bootstrap5.min.js"></script>
<script src="libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="libs/datatables.net-buttons/js/buttons.flash.min.js"></script>
<script src="libs/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="libs/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
<script src="libs/datatables.net-select/js/dataTables.select.min.js"></script>
<script src="libs/pdfmake/build/pdfmake.min.js"></script>
<script src="libs/pdfmake/build/vfs_fonts.js"></script>

<script src="js/pages/form-advanced.init.js"></script>

<script src="js/pages/datatables.init.js"></script>

<script src="js/pages/dashboard-1.init.js"></script>

<script src="js/pages/authentication.init.js"></script>
<script src="libs/quill/quill.min.js"></script>

<script src="lib/utilityFunction.js"></script>

<script src="js/jquery-ui.min.js"></script>

<script src="libs/parsleyjs/parsley.min.js"></script>
<script src="js/pages/form-validation.init.js"></script>


<script src="libs/jquery-toast-plugin/jquery.toast.min.js"></script><!-- notification JS  -->
<script src="js/pages/toastr.init.js"></script><!-- notification JS  -->
<script src="libs/ladda/spin.min.js"></script>
<script src="libs/ladda/ladda.min.js"></script>

<!-- Buttons init js-->
<script src="js/pages/loading-btn.init.js"></script>

<!-- DataTables FixedColumns JS -->
<script src="js/dataTables.fixedColumns.min.js"></script>

<script src="libs/moment/min/moment.min.js"></script>
<script src="libs/fullcalendar/main.min.js"></script>

<!-- Calendar init -->
<script src="js/pages/calendar.init.js"></script>