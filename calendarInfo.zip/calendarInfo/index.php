<?php
session_start();
ob_start();
date_default_timezone_set("Asia/Kolkata");
include('lib/connect.php');
$errormsg = "";
$successmsg = "";
$CreatedDate = date('Y-m-d H:i:s');

if (isset($_REQUEST['success'])) {
    $successmsg = "<div id='messagegreen' class='alert alert-success alert-dismissable' style='color: Green; font-weight: bold; font-size: 14px;'> <button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button>Password has been changed successfully.</div>";
}

if (isset($_POST['btnsubmit'])) {
    $emailid = $con->real_escape_string(trim($_POST['txtemail']));
    $password = $con->real_escape_string(trim($_POST['txtpassword']));
    $query = "SELECT users.*, company.coid, company.coname FROM users INNER JOIN company ON company.coid = users.coid WHERE users.useremailid='$emailid'";
    $result = mysqli_query($con, $query) or die(mysqli_error($con));
    if (mysqli_num_rows($result) == 0) {
        $errormsg = "<div id='messageerror' class='alert alert-danger font-weight-bold'><i class='mdi mdi-block-helper mr-2'></i> Email does not exist.</div>";
    } else {
        $row = mysqli_fetch_array($result);
        if ($row['active'] != '1') {
            $errormsg = "<div id='messageerror' class='alert alert-danger font-weight-bold'><i class='mdi mdi-block-helper mr-2'></i> Account is inactive. <a href='mailto:'><strong>Please contact admin.</strong></a></div>";
        } else if ($row['userpassword'] == $password) {

            function getUserIpAddr()
            {
                $ipaddress = '';
                if (!empty($_SERVER['REMOTE_ADDR'])) {
                    $ipaddress = $_SERVER['REMOTE_ADDR'];
                } else {
                    $ipaddress = 'UNKNOWN';
                }
                return $ipaddress;
            }

            $get_lastlogin = mysqli_query($con, "SELECT createdate FROM sessions WHERE userid='{$row['userid']}' ORDER BY id DESC LIMIT 1;") or die(mysqli_error($con));
            if (mysqli_num_rows($get_lastlogin) > 0) {
                $row_lastlogin = mysqli_fetch_assoc($get_lastlogin);
                $lastLoginTIme = $row_lastlogin['createdate'];
            } else {
                $lastLoginTIme = date('Y-m-d H:i:s');
            }

            $SessionIp = getUserIpAddr();
            $_SESSION['userfirstname'] = $row['userfirstname'];
            $_SESSION['usertype'] = $row['usertype'];
            $_SESSION['userid'] = $row['userid'];
            $_SESSION['coid'] = $row['coid'];
            $_SESSION['coname'] = $row['coname'];
            $_SESSION['lastLoginTIme'] = $lastLoginTIme;
            $SessionKey = session_id();
            $_SESSION['IP'] = $SessionIp;

            $query1 = "Insert into sessions (userid, sessionkey, sessionip, createdate, active) values('{$row['userid']}', '$SessionKey', '$SessionIp', '$CreatedDate','1');";
            $result1 = mysqli_query($con, $query1) or die(mysqli_error($con));
            if ($result1 == 1) {
                echo "<script>window.location.href='dashboard.php'</script>";
            } else {
                $errormsg = "<div class='alert alert-danger'> <strong>Oh snap!</strong> Something went wrong. Please try after sometimes.</div>";
            }
        } else {
            $errormsg = "<div class='alert alert-danger'> <strong>Oh snap!</strong> Invalid username or password. Try again.</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-menu-color="brand">

<head>
    <title>Log In :: Calendar Test</title>
    <?php include('cssjs.php'); ?>
    <script src="js/js-ajex.js"></script>
    <script>
        $(document).ready(function() {
            $('#messagegreen').fadeIn('slow').delay(2500).fadeOut('slow');
            $('#messageerror').fadeIn('slow').delay(2500).fadeOut('slow');
        });
    </script>
</head>

<body class="authentication-bg authentication-bg-pattern">
    <div class="account-pages mt-4 mb-4">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-5">
                    <div class="card bg-pattern">
                        <div class="card-body p-4">
                            <div class="text-center w-75 m-auto">
                                <div class="auth-brand">
                                    <a href="#" class="logo logo-dark text-center">
                                        <span class="logo-lg">
                                            <img src="images/logo.png" alt="" height="76">
                                        </span>
                                    </a>
                                </div>
                                <div id="messageerror"><?php echo $errormsg; ?></div>
                                <p class="text-muted mb-2 mt-2">Enter your Email Id and password to access admin panel.</p>
                            </div>
                            <form action="#" method="post" enctype="multipart/form-data" autocomplete="off">
                                <div class="mb-3">
                                    <label for="txtemail" class="form-label"><span class="text-danger">*</span>Email id</label>
                                    <input type="email" id="txtemail" name="txtemail" class="form-control" placeholder="Enter your email id" tabindex="1" autofocus required>
                                </div>
                                <div class="mb-3">
                                    <a href="forgot-password.php" class="text-muted float-end"><small>Forgot your password?</small></a>
                                    <label for="txtpassword" class="form-label"><span class="text-danger">*</span>Password</label>
                                    <div class="input-group input-group-merge">
                                        <input type="password" id="txtpassword" name="txtpassword" class="form-control" placeholder="Enter your password" tabindex="2" required>
                                        <div class="input-group-text" data-password="false">
                                            <span class="password-eye"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-grid">
                                    <button type="submit" id="btnsubmit" name="btnsubmit" class="btn btn-success waves-effect waves-light" tabindex="3">Log In </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="footer footer-alt text-white-50">
        2024 - <script>
            document.write(new Date().getFullYear())
        </script> &copy; Calendar Test </a>
    </footer>
    <?php include('bottom.php'); ?>
</body>

</html>