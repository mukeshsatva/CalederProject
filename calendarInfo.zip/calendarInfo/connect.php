<?php
// $con = mysqli_connect('localhost', 'root', '');
// mysqli_select_db($con,"transdirectory_travel")or die(mysqli_error($con));
$con = mysqli_connect('localhost', 'transdds_transdirectory', 'transdds_transdirectory');
mysqli_select_db($con,"transdds_transdirectory")or die(mysqli_error($con));
?>
