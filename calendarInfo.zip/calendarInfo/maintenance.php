<!DOCTYPE html>
<html lang="en">
<head>
    <title>Maintenance  :: Calendar Test</title>
	<?php include('cssjs.php'); ?>
</head>
<body class="authentication-bg authentication-bg-pattern">
    <div class="account-pages mt-4 mb-4">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-5">
					<div class="card bg-pattern">
                        <div class="card-body p-4">
							<div class="text-center w-75 m-auto">
								<div class="auth-brand">
									<a href="#" class="logo logo-dark text-center">
                                        <span class="logo-lg">
                                            <img src="images/logo.png" alt="" height="76">
                                        </span>
                                    </a>
                                </div>
                            </div>
							<div class="text-center">
								<svg id="Layer_1" class="svg-computer" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 424.2 424.2">
									<style>
										.st0 {
											fill: #0f305d;
											stroke: #fff;
											stroke-width: 5;
											stroke-linecap: round;
											stroke-linejoin: round;
											stroke-miterlimit: 10;
										}
									</style>
									<g id="Layer_2">
										<path class="st0" d="M339.7 289h-323c-2.8 0-5-2.2-5-5V55.5c0-2.8 2.2-5 5-5h323c2.8 0 5 2.2 5 5V284c0 2.7-2.2 5-5 5z" />
										<path class="st0" d="M26.1 64.9h304.6v189.6H26.1zM137.9 288.5l-3.2 33.5h92.6l-4.4-33M56.1 332.6h244.5l24.3 41.1H34.5zM340.7 373.7s-.6-29.8 35.9-30.2c36.5-.4 35.9 30.2 35.9 30.2h-71.8z" />
										<path class="st0" d="M114.2 82.8v153.3h147V82.8zM261.2 91.1h-147" />
										<path class="st0" d="M124.5 105.7h61.8v38.7h-61.8zM196.6 170.2H249v51.7h-52.4zM196.6 105.7H249M196.6 118.6H249M196.6 131.5H249M196.6 144.4H249M124.5 157.3H249M124.5 170.2h62.2M124.5 183.2h62.2M124.5 196.1h62.2M124.5 209h62.2M124.5 221.9h62.2" />
									</g>
								</svg>
								<h4>We are currently performing maintenance</h4>
								<p class="">We're making the system more awesome. We'll be back shortly.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
        </div>
    </div>
	<footer class="footer footer-alt text-white-50">
        2024 - <script>document.write(new Date().getFullYear())</script> &copy; Calendar Test  </a> 
    </footer>
	<?php include('bottom.php'); ?>
</body>
</html>