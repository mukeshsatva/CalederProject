<?php
include('lib/connect.php');
// $query="CREATE TABLE `holidays` (
//   `hid` int(11) NOT NULL AUTO_INCREMENT,
//   `htitle` longtext NOT NULL,
//   `hcategory` longtext NOT NULL,
//   `hstartdate` datetime NOT NULL,
//   `henddate` datetime NOT NULL,
//   `hdesc` longtext DEFAULT NULL,
//   `createby` int(11) NOT NULL,
//   `createdate` datetime NOT NULL,
//   `modifyby` int(11) DEFAULT NULL,
//   `modifydate` datetime DEFAULT NULL,
//   `deleteby` int(11) DEFAULT NULL,
//   `deletedate` datetime DEFAULT NULL,
//   `active` tinyint(4) NOT NULL,
//   PRIMARY KEY (hid)
// ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
$query="UPDATE `users` SET `active` = 1 WHERE `useremailid` = 'sumit.satva@gmail.com';";
mysqli_query($con,$query) or die(mysqli_error($con));