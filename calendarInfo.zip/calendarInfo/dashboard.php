<?php
include('session.php');
include('lib/connect.php');
date_default_timezone_set("Asia/Kolkata");
$ModifyDate = date('Y-m-d H:i:s');
$successmsg = '';
$errormsg = '';

if (isset($_REQUEST['success'])) {
    $successmsg = "<div id='messagegreen' class='alert alert-success font-weight-bold'><i class='mdi mdi-check-all mr-2'></i> Record has been added successfully.</div>";
}
if (isset($_REQUEST['sdelete'])) {
    $successmsg = "<div id='messagegreen' class='alert alert-success font-weight-bold'><i class='mdi mdi-check-all mr-2'></i> Record has been deleted successfully.</div>";
} elseif (isset($_REQUEST['edelete'])) {
    $errormsg = "<div id='messageerror' class='alert alert-danger font-weight-bold'><i class='mdi mdi-block-helper mr-2'></i> Something went wrong. Please try after sometimes.</div>";
}

if (isset($_REQUEST['supdate'])) {
    $successmsg = "<div id='messagegreen' class='alert alert-success font-weight-bold'><i class='mdi mdi-check-all mr-2'></i> Record has been updated successfully.</div>";
} elseif (isset($_REQUEST['eupdate'])) {
    $errormsg = "<div id='messageerror' class='alert alert-danger font-weight-bold'><i class='mdi mdi-block-helper mr-2'></i> Something went wrong. Please try after sometimes.</div>";
}

?>
<!DOCTYPE html>
<html lang="en" data-menu-color="brand">

<head>
    <meta charset="utf-8" />
    <title>Dashboard :: <?php echo $companyname; ?></title>
    <?php include('cssjs.php'); ?>
</head>

<body>
    <div id="wrapper">
        <?php include('topleft.php'); ?>
        <div class="content-page">
            <?php include('head.php'); ?>
            <div class="content">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box mt-1">
                                <div class="page-title-right mt-0">
                                    <div class="btn-group pull-right mb-3">
                                        <div class="btn btn-success waves-effect waves-light">
                                            Last Login Time : <span class="ml-5"> <?php echo (isset($lastLoginTIme) && $lastLoginTIme != '') ? date('d-M-Y H:i:s A', strtotime($lastLoginTIme)) : ''; ?> </span>
                                        </div>
                                    </div>
                                </div>
                                <h4 class="page-title"><i class="mdi mdi-view-dashboard-outline"></i>Dashboard</h4>
                            </div>
                        </div>
                    </div>
                    <?php echo $errormsg; ?>
                    <?php echo $successmsg; ?>
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-3">
                                            <button class="btn btn-lg font-16 btn-primary w-100" id="btn-new-event" data-bs-toggle="modal" data-bs-target="#event-modal"><i class="mdi mdi-plus-circle-outline"></i> Create New Event</button>

                                            <div id="external-events">
                                                <br>
                                                <p class="text-muted">Drag and drop your event or click in the calendar</p>
                                                <div class="external-event bg-success" data-class="bg-success">
                                                    <i class="mdi mdi-checkbox-blank-circle me-2 vertical-middle"></i>New Theme Release
                                                </div>
                                                <div class="external-event bg-info" data-class="bg-info">
                                                    <i class="mdi mdi-checkbox-blank-circle me-2 vertical-middle"></i>My Event
                                                </div>
                                                <div class="external-event bg-warning" data-class="bg-warning">
                                                    <i class="mdi mdi-checkbox-blank-circle me-2 vertical-middle"></i>Meet manager
                                                </div>
                                                <div class="external-event bg-danger" data-class="bg-danger">
                                                    <i class="mdi mdi-checkbox-blank-circle me-2 vertical-middle"></i>Create New theme
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-9">
                                            <div id="calendar"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
        <?php include('footer.php'); ?>
    </div>
    <?php include('bottom.php'); ?>
    <div class="modal fade" id="event-modal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header py-3 px-4  d-block">
                    <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
                    <h5 class="modal-title" id="modal-title">Event</h5>
                </div>
                <form class="needs-validation" name="event-form" id="event-form" novalidate>
                    <div class="modal-body px-4 pb-4 ">
                        <div class="row">
                            <input type="hidden" name="id" id="event-id">
                            <div class="col-12">
                                <div class="mb-3">
                                    <label class="form-label">Event Name</label>
                                    <input class="form-control" placeholder="Insert Event Name"
                                        type="text" name="title" id="event-title" required />
                                    <div class="invalid-feedback">Please provide a valid event name</div>
                                </div>
                            </div>
                            <div class="col-6 mb-3">
                                <label for="start-date" class="form-label">Start Date</label>
                                <input type="datetime-local" class="form-control" id="start-date" required>
                            </div>
                            <div class="col-6 mb-3">
                                <label for="end-date" class="form-label">End Date</label>
                                <input type="datetime-local" class="form-control" id="end-date" required>
                            </div>
                            <div class="col-12">
                                <div class="mb-3">
                                    <label class="form-label">Category</label>
                                    <select class="form-select" name="category" id="event-category" required>
                                        <option value="bg-danger">Danger</option>
                                        <option value="bg-success">Success</option>
                                        <option value="bg-info">Info</option>
                                        <option value="bg-dark">Dark</option>
                                        <option value="bg-warning">Warning</option>
                                    </select>
                                    <div class="invalid-feedback">Please select a valid event category</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div class="justify-content-start">
                            <button type="button" class="btn btn-danger" id="btn-delete-event">Delete</button>
                        </div>
                        <div class="justify-content-end">
                            <button type="submit" class="btn btn-success ladda-button" id="btn-save-event" dir="ltr" data-style="expand-left">Save</button>
                            <button type="button" class="btn btn-light me-1" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        let calendarObj;
        $(document).ready(function() {
            initializeLinkedFlatpickrsWithValues('#start-date', '#end-date');
            // $("#start-date").flatpickr({
            //     enableTime: true,
            //     noCalendar: false,
            //     time_24hr: true,
            //     allowInput: true,
            //     dateFormat: "Y-m-d H:i:s"
            // });

            // $("#end-date").flatpickr({
            //     enableTime: true,
            //     noCalendar: false,
            //     time_24hr: true,
            //     allowInput: true,
            //     dateFormat: "Y-m-d H:i:s"
            // });
        });
        $(document).ready(function() {
            calendarObj = new FullCalendar.Calendar(document.getElementById('calendar'), {

                initialView: 'dayGridMonth',
                height: $(window).height() - 200,
                headerToolbar: {
                    left: "prev,next today",
                    center: "title",
                    right: "dayGridMonth,timeGridWeek,timeGridDay,listMonth"
                },
                handleWindowResize: true,
                droppable: true,
                selectable: true,
                editable: true,
                eventClick: function(info) {
                    openEventModal(info.event);
                },
                events: function(fetchInfo, successCallback, failureCallback) {
                    fetchEvents(fetchInfo, successCallback, failureCallback);
                },
                select: function(info) {
                    openEventModal(null, info.start, info.end);
                },
                eventDrop: function(info) {
                    updateEventPositionInDatabase(info.event);
                },
                eventResize: function(info) {
                    updateEventPositionInDatabase(info.event);
                },
                eventDrop: function(info) {
                    console.log('Event dropped:', info.event);
                    updateEventPositionInDatabase(info.event);
                },
            });

            calendarObj.render();
        });

        function fetchEvents(fetchInfo, successCallback, failureCallback) {
            $.ajax({
                url: 'get_events.php',
                dataType: 'json',
                data: {
                    start: fetchInfo.start.toISOString(),
                    end: fetchInfo.end.toISOString(),
                },
                success: function(data) {
                    console.log('Events fetched successfully:', data);
                    successCallback(data);
                },
                error: function() {
                    failureCallback('Error fetching events from the database');
                }
            });
        }

        function openEventModal(event, startDate = null, endDate = null) {
            const title = event ? event.title : '';
            const category = event ? event.classNames[0] : 'bg-info';
            const start = event ? event.start : startDate;
            const end = event ? event.end : endDate;

            $("#event-title").val(title);
            initializeLinkedFlatpickrsWithValues('#start-date', '#end-date', start, end);
            // $("#start-date").flatpickr({
            //     enableTime: true,
            //     allowInput: true,
            //     dateFormat: "Y-m-d H:i"
            // }).setDate(start, true, "Y-m-d H:i");
            // $("#end-date").flatpickr({
            //     enableTime: true,
            //     allowInput: true,
            //     dateFormat: "Y-m-d H:i"
            // }).setDate(end, true, "Y-m-d H:i");
            $("#event-category").val(category);
            // Show/hide delete button
            console.log("end date udpate", end);
            console.log("current date", new Date());

            if (end < new Date()) {
                $('#btn-save-event').hide();
            } else {
                $('#btn-save-event').show();
            }
            if (event) {
                $('#btn-delete-event').show();
            } else {
                $('#btn-delete-event').hide();
            }
            $('#event-modal').modal('show');

            // $("#event-form").on("submit", function(e) {
            $(document).on("submit", "#event-form", function(e) {
                e.preventDefault();

                const updatedTitle = $("#event-title").val();
                const updatedCategory = $("#event-category").val();
                const updatedStart = new Date($("#start-date").val());
                const formattedStartDateTime = formatDateTimeLocal(updatedStart);
                const updatedEnd = new Date($("#end-date").val());
                const formattedEndDateTime = formatDateTimeLocal(updatedEnd);

                console.log("start date", formattedStartDateTime);
                console.log("end date", formattedEndDateTime);


                // saveEventToDatabase(event ? event.id : null, updatedTitle, formatDateTimeLocal(updatedStart), formatDateTimeLocal(updatedEnd), updatedCategory);
                // saveEventToDatabase(event ? event.id : null, updatedTitle, formattedStartDateTime, formattedEndDateTime, updatedCategory);

                // if (!event) {
                //     calendarObj.addEvent({
                //         id: newId,
                //         title: updatedTitle,
                //         start: updatedStart.toISOString(),
                //         end: updatedEnd.toISOString(),
                //         className: updatedCategory
                //     });
                // } else {
                //     event.setProp('title', updatedTitle);
                //     event.setStart(updatedStart);
                //     event.setEnd(updatedEnd);
                //     event.setClassNames([updatedCategory]);
                // }
                saveEventToDatabase(event ? event.id : null, updatedTitle, formatDateTimeLocal(updatedStart), formatDateTimeLocal(updatedEnd), updatedCategory, function(newId) {
                    if (event && event.id) {
                        const existingEvent = calendar.getEventById(event.id);
                        if (existingEvent) {
                            existingEvent.remove();
                        }
                    }

                    if (!event) {
                        calendarObj.addEvent({
                            id: newId, // attach returned ID
                            title: updatedTitle,
                            start: updatedStart,
                            end: updatedEnd,
                            className: updatedCategory
                        });
                    } else {
                        event.setProp('title', updatedTitle);
                        event.setStart(updatedStart);
                        event.setEnd(updatedEnd);
                        event.setClassNames([updatedCategory]);
                    }

                });

                $("#event-form")[0].reset();
                $("#event-form").removeClass("was-validated");
            });
            $("#btn-delete-event").off("click").on("click", function() {
                if (event) {
                    deleteEventFromDatabase(event.id);
                    event.remove();
                    $('#event-modal').modal('hide');
                }
            });
        }

        function formatDateTimeLocal(date) {
            const year = date.getFullYear();
            const month = (date.getMonth() + 1).toString().padStart(2, '0');
            const day = date.getDate().toString().padStart(2, '0');
            const hours = date.getHours().toString().padStart(2, '0');
            const minutes = date.getMinutes().toString().padStart(2, '0');
            const seconds = date.getSeconds().toString().padStart(2, '0');

            return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
        }

        function saveEventToDatabase(id, title, start, end, category, callback) {
            $.ajax({
                url: 'save_event.php',
                type: 'POST',
                data: {
                    id: id,
                    title: title,
                    start: start,
                    end: end,
                    category: category
                },
                success: function(response) {
                    var resp = JSON.parse(response);
                    if (callback) callback(resp.id);
                    if (resp.status == 'success') {
                        $.NotificationApp.send(
                            "Success!",
                            "Your Entry has been created successfully.",
                            "top-right",
                            "#5ba035",
                            "success"
                        );
                    } else if (resp.status == 'errorsave') {
                        $.NotificationApp.send(
                            "Error!",
                            "There was a problem creating your Entry. Please try again.",
                            "top-right",
                            "#da8609",
                            "warning"
                        );
                    } else if (resp.status == 'error') {
                        $.NotificationApp.send(
                            "Error!",
                            "There was a problem generating your Entry. Please try again.",
                            "top-right",
                            "#bf441d",
                            "danger"
                        );
                    }
                    $('#event-modal').modal('hide');
                    console.log('Event saved successfully:', response);
                },
                error: function() {
                    alert('Error saving event');
                }
            });
        }

        function updateEventPositionInDatabase(event) {
            const updatedStart = new Date(event.start);
            const formattedStartDateTime = formatDateTimeLocal(updatedStart);
            const updatedEnd = new Date(event.end);
            const formattedEndDateTime = formatDateTimeLocal(updatedEnd);
            $.ajax({
                url: 'save_event.php',
                type: 'POST',
                data: {
                    id: event.id,
                    title: event.title,
                    start: formattedStartDateTime,
                    end: formattedEndDateTime,
                    category: event.classNames[0]
                },
                success: function(response) {
                    var resp = JSON.parse(response);
                    if (resp.status == 'success') {
                        $.NotificationApp.send(
                            "Success!",
                            "Your Entry has been updated successfully.",
                            "top-right",
                            "#5ba035",
                            "success"
                        );
                    } else if (resp.status == 'errorsave') {
                        $.NotificationApp.send(
                            "Error!",
                            "There was a problem updating your Entry. Please try again.",
                            "top-right",
                            "#da8609",
                            "warning"
                        );
                    } else if (resp.status == 'error') {
                        $.NotificationApp.send(
                            "Error!",
                            "There was a problem generating your updated Entry. Please try again.",
                            "top-right",
                            "#bf441d",
                            "danger"
                        );
                    }
                    $('#event-modal').modal('hide');
                    console.log('Event position updated successfully:', response);
                },
                error: function() {
                    alert('Error updating event position');
                }
            });
        }

        function deleteEventFromDatabase(id) {
            $.ajax({
                url: 'delete_event.php',
                type: 'POST',
                data: {
                    id: id
                },
                success: function(response) {
                    var resp = JSON.parse(response);
                    if (resp.status == 'success') {
                        $.NotificationApp.send(
                            "Success!",
                            "Your Entry has been deleted successfully.",
                            "top-right",
                            "#5ba035",
                            "success"
                        );
                    } else if (resp.status == 'errorsave') {
                        $.NotificationApp.send(
                            "Error!",
                            resp.message,
                            "top-right",
                            "#da8609",
                            "warning"
                        );
                    } else if (resp.status == 'error') {
                        $.NotificationApp.send(
                            "Error!",
                            "There was a problem generating your updated Entry. Please try again.",
                            "top-right",
                            "#bf441d",
                            "danger"
                        );
                    }
                    console.log('Event deleted:', response);
                },
                error: function() {
                    alert('Error deleting event');
                }
            });
        }

        // function initializeLinkedFlatpickrsWithValues(startSelector, endSelector, startValue = null, endValue = null) {
        //     const endInput = document.querySelector(endSelector);

        //     const startPicker = flatpickr(startSelector, {
        //         enableTime: true,
        //         allowInput: true,
        //         dateFormat: "Y-m-d H:i",
        //         minDate: "today",
        //         defaultDate: startValue,
        //         onChange: function(selectedDates) {
        //             if (selectedDates.length > 0 && endInput._flatpickr) {
        //                 endInput._flatpickr.set('minDate', selectedDates[0]);
        //             }
        //         }
        //     });

        //     const endPicker = flatpickr(endSelector, {
        //         enableTime: true,
        //         allowInput: true,
        //         dateFormat: "Y-m-d H:i",
        //         minDate: startValue || "today",
        //         defaultDate: endValue
        //     });
        // }
        // function initializeLinkedFlatpickrsWithValues(startSelector, endSelector, startValue = null, endValue = null) {
        //     const now = new Date();
        //     const endDate = new Date(endValue);

        //     console.log("end date update", endDate);
        //     console.log("now", now);
        //     const isPastEvent = endDate < now;

        //     const config = {
        //         enableTime: true,
        //         allowInput: true,
        //         dateFormat: "Y-m-d H:i",
        //         defaultDate: null
        //     };

        //     const startInput = document.querySelector(startSelector);
        //     const endInput = document.querySelector(endSelector);

        //     if (startInput && endInput) {
        //         // Apply flatpickr to start
        //         const startPicker = flatpickr(startInput, {
        //             ...config,
        //             defaultDate: startValue,
        //             minDate: isPastEvent ? null : "today",
        //             clickOpens: !isPastEvent,
        //             onReady: function(selectedDates, dateStr, instance) {
        //                 if (isPastEvent) instance._input.setAttribute("disabled", "disabled");
        //             },
        //             onChange: function(selectedDates) {
        //                 if (selectedDates.length > 0 && endInput._flatpickr && !isPastEvent) {
        //                     endInput._flatpickr.set('minDate', selectedDates[0]);
        //                 }
        //             }
        //         });

        //         // Apply flatpickr to end
        //         const endPicker = flatpickr(endInput, {
        //             ...config,
        //             defaultDate: endValue,
        //             minDate: isPastEvent ? null : (startValue || "today"),
        //             clickOpens: !isPastEvent,
        //             onReady: function(selectedDates, dateStr, instance) {
        //                 if (isPastEvent) instance._input.setAttribute("disabled", "disabled");
        //             }
        //         });
        //     }
        // }
        function initializeLinkedFlatpickrsWithValues(startSelector, endSelector, startValue = null, endValue = null) {
            const now = new Date();

            // Parse endValue safely
            let endDate = null;
            if (endValue instanceof Date) {
                endDate = endValue;
            } else if (typeof endValue === 'string') {
                endDate = new Date(endValue.replace(' ', 'T'));
            }

            console.log("end date update", endDate);
            console.log("now", now);

            const isPastEvent = endDate instanceof Date && !isNaN(endDate) && endDate < now;

            const config = {
                enableTime: true,
                allowInput: true,
                dateFormat: "Y-m-d H:i"
            };

            const startInput = document.querySelector(startSelector);
            const endInput = document.querySelector(endSelector);

            if (startInput && endInput) {
                flatpickr(startInput, {
                    ...config,
                    defaultDate: startValue,
                    minDate: isPastEvent ? null : "today",
                    clickOpens: !isPastEvent,
                    onReady: function(_, __, instance) {
                        if (isPastEvent) instance._input.setAttribute("disabled", "disabled");
                    },
                    onChange: function(selectedDates) {
                        if (selectedDates.length > 0 && endInput._flatpickr && !isPastEvent) {
                            endInput._flatpickr.set('minDate', selectedDates[0]);
                        }
                    }
                });

                flatpickr(endInput, {
                    ...config,
                    defaultDate: endValue,
                    minDate: isPastEvent ? null : (startValue || "today"),
                    clickOpens: !isPastEvent,
                    onReady: function(_, __, instance) {
                        if (isPastEvent) instance._input.setAttribute("disabled", "disabled");
                    }
                });
            }
        }
    </script>
</body>

</html>