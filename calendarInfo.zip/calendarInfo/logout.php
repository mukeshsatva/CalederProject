<?php
session_start();
session_unset();
session_destroy();
?>
<!DOCTYPE html>
<html lang="en" data-menu-color="brand">
<head>
    <title>Logout  :: Calendar Test</title>
    <?php include('cssjs.php'); ?>
</head>
<body class="authentication-bg authentication-bg-pattern">
    <div class="account-pages mt-4 mb-4">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-5">
					<div class="card bg-pattern">
                        <div class="card-body p-4">
							<div class="text-center w-75 m-auto">
								<div class="auth-brand">
									<a href="#" class="logo logo-dark text-center">
                                        <span class="logo-lg">
                                            <img src="images/logo.png" alt="" height="76">
                                        </span>
                                    </a>
                                </div>
							</div>
							<div class="text-center w-100">
								<div class="mt-4">
									<div class="logout-checkmark">
										<svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 130.2 130.2">
											<circle class="path circle" fill="none" stroke="#4ca12d" stroke-width="6" stroke-miterlimit="10" cx="65.1" cy="65.1" r="62.1" />
											<polyline class="path check" fill="none" stroke="#4ca12d" stroke-width="6" stroke-linecap="round" stroke-miterlimit="10" points="100.2,40.2 51.5,88.8 29.8,67.5 " />
										</svg>
									</div>
								</div>
								<h3>See you again !</h3>
								<p class="text-muted"> You are now successfully sign out. </p>
							</div>
							<a href="index.php" class="btn w-100 btn-primary waves-effect waves-light mt-3">Back to Sign-in</a>
						</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="footer footer-alt text-white-50">
        2024 - <script>document.write(new Date().getFullYear())</script> &copy; Calendar Test  </a> 
    </footer>
	<?php include('bottom.php'); ?>
</body>
</html>