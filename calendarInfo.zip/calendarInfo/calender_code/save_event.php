<?php
// save_event.php
include('lib/connect.php');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = isset($_POST['id']) ? intval($_POST['id']) : null;
    $title = $_POST['title'];
    $startDate = $_POST['start'];
    $endDate = $_POST['end'];
    $category = $_POST['category'];
    $createdBy = 1;
    $createDate = date('Y-m-d H:i:s');
    $active = 1;

    if ($id) {
        $query = "UPDATE holidays SET htitle='$title', hstartdate='$startDate', henddate='$endDate', hcategory='$category', modifyby='$createdBy', modifydate='$createDate', active='1' WHERE hid='$id'";
    } else {
        $query = "INSERT INTO holidays (htitle, hstartdate, henddate,hcategory, createby, createdate, active) VALUES ('$title', '$startDate', '$endDate','$category', '$createdBy', '$createDate', '1')";
    }

    if ($result = mysqli_query($con, $query) or die(mysqli_error($con))) {
        if ($result == 1) {
            $id = $id ? $id : mysqli_insert_id($con);
            echo json_encode(['status' => 'success', 'id' => $id]);
        } else {
            echo json_encode(['status' => 'errorsave', 'message' => 'Failed to save event']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to prepare statement']);
    }
}
