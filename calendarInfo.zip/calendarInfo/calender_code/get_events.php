<?php
// get_events.php
include('lib/connect.php');
header('Content-Type: application/json');

$events = [];

if (isset($_GET['start']) && isset($_GET['end'])) {
    $start = mysqli_real_escape_string($con, $_GET['start']);
    $end = mysqli_real_escape_string($con, $_GET['end']);

    $query = "SELECT * FROM holidays WHERE active = 1 AND ( hstartdate BETWEEN '$start' AND '$end' OR henddate BETWEEN '$start' AND '$end')";
    $result = mysqli_query($con, $query);

    while ($row = mysqli_fetch_assoc($result)) {
        $events[] = [
            'id' => $row['hid'],
            'title' => $row['htitle'],
            'start' => $row['hstartdate'],
            'end' => $row['henddate'],
            'description' => $row['hdesc'],
            'className' => $row['hcategory']
        ];
    }
}

echo json_encode($events);
exit;
