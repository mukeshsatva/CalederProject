<?php
// fill_calender.php
include('lib/connect.php');

for ($i = 0; $i < 30; $i++) {
    $title = "Event " . ($i + 1);
    $startDate = date('Y-m-d H:i:s', mt_rand(strtotime('2020-01-01'), strtotime('2020-12-31')));
    $endDate = date('Y-m-d H:i:s', mt_rand(strtotime($startDate), strtotime('+1 year')));
    $category = array('bg-primary', 'bg-success', 'bg-info', 'bg-warning', 'bg-danger')[mt_rand(0, 4)];
    $createdBy = 1;
    $createDate = date('Y-m-d H:i:s');
    $active = 1;

    $query = "INSERT INTO holidays (htitle, hstartdate, henddate,hcategory, createby, createdate, active) VALUES ('$title', '$startDate', '$endDate','$category', '$createdBy', '$createDate', '1')";

    if (!$result = mysqli_query($con, $query)) {
        echo json_encode(['status' => 'error', 'message' => 'Failed to save event: ' . mysqli_error($con)]);
        exit;
    }
}

echo json_encode(['status' => 'success']);

