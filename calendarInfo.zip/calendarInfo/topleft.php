<div class="app-menu">
    <div class="logo-box">
        <a href="dashboard.php" class="logo-light">
            <img src="images/logo.png" alt="" class="logo-lg">
            <img src="images/logo.png" alt="" class="logo-sm">
        </a>
    </div>
    <div class="scrollbar">
        <ul class="menu">

            <li class="menu-title">Navigation</li>

            <li class="menu-item">
                <a href="dashboard.php" class="menu-link">
                    <span class="menu-icon"><i class="mdi mdi-view-dashboard-outline"></i></span>
                    <span class="menu-text"> Dashboard </span>
                </a>
            </li>
        </ul>
        <div class="clearfix"></div>
    </div>
</div>