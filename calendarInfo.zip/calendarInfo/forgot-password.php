<?php
include('lib/connect.php');
date_default_timezone_set("Asia/Kolkata");
$ModifyDate = date('Y-m-d H:i:s');
$successmsg = '';
$errormsg = '';
if (isset($_SESSION['success'])) {
    $successmsg = "<div id='messagegreen' class='alert alert-success font-weight-bold'><i class='mdi mdi-check-all mr-2'></i> Record has been added successfully.</div>";
    unset($_SESSION['success']);
}
if (isset($_SESSION['sdelete'])) {
    $successmsg = "<div id='messagegreen' class='alert alert-success font-weight-bold'><i class='mdi mdi-check-all mr-2'></i> Record has been deleted successfully.</div>";
    unset($_SESSION['sdelete']);
} elseif (isset($_SESSION['edelete'])) {
    $errormsg = "<div id='messageerror' class='alert alert-danger font-weight-bold'><i class='mdi mdi-block-helper mr-2'></i> Something went wrong. Please try after sometimes.</div>";
    unset($_SESSION['edelete']);
}

if (isset($_SESSION['supdate'])) {
    $successmsg = "<div id='messagegreen' class='alert alert-success font-weight-bold'><i class='mdi mdi-check-all mr-2'></i> Record has been updated successfully.</div>";
    unset($_SESSION['supdate']);
} elseif (isset($_SESSION['eupdate'])) {
    $errormsg = "<div id='messageerror' class='alert alert-danger font-weight-bold'><i class='mdi mdi-block-helper mr-2'></i> Something went wrong. Please try after sometimes.</div>";
    unset($_SESSION['eupdate']);
}


if (isset($_POST['btnsubmit'])) {
    $email = $_POST['txtemail'];
    $query = "select userpassword, active from users where useremailid='$email'";
    $result = mysqli_query($con, $query) or die(mysqli_error($con));
    $row = mysqli_fetch_array($result);
    if (mysqli_num_rows($result)) {
        $active = $row['active'];
        if ($active != '1') {
            $errormsg = "<div id='messageerror' class='alert alert-danger font-weight-bold'><i class='mdi mdi-block-helper mr-2'></i> Profile is inactive. <a href='mailto:'><strong>Please contact the admin.</strong></a></div>";
        } else {
            $password = $row['userpassword'];
            $mailbody = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
                        <html xmlns='http://www.w3.org/1999/xhtml' style='font-family: Helvetica Neue, Helvetica, Arial, sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;'>

                        <head>
                            <meta name='viewport' content='width=device-width' />
                            <meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
                            <title>Calendar Test</title>
                        </head>

                        <body style='font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; -webkit-font-smoothing: antialiased; -webkit-text-size-adjust: none; width: 100% !important; height: 100%; line-height: 1.6em; background-color: #f6f6f6; margin: 0;' bgcolor='#f6f6f6'> 
                        <table class='body-wrap' style='font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; width: 100%; background-color: #f6f6f6; margin: 0;'
                            bgcolor='#f6f6f6'>
                            <tr style='font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;'>
                                <td style='font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0;' valign='top'></td>
                                <td class='container' width='600' style='font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; display: block !important; max-width: 600px !important; clear: both !important; margin: 0 auto;' valign='top'>
                                    <div class='content' style='font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; max-width: 600px; display: block; margin: 0 auto; padding: 20px;'>
                                        <table class='main' width='100%' cellpadding='0' cellspacing='0' itemprop='action' itemscope itemtype='http://schema.org/ConfirmAction' style='font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; border-radius: 3px; margin: 0; border: none;'>
                                            <tr style='font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;'>
                                                <td class='content-wrap' style='font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0;padding: 30px;border: 3px solid #4fc6e1;border-radius: 7px; background-color: #fff;' valign='top'>
                                                    <meta itemprop='name' content='Confirm Email' style='font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;' />
                                                    <table width='100%' cellpadding='0' cellspacing='0' style='font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;'>
                                                        <tr>
                                                            <td style='text-align: center'>
                                                                <a href='#' style='display: block;margin-bottom: 10px;'> <img src='https://transdirectory.in/ghconsultancy/images/logo-wide.png' height='24' alt='logo' /></a> <br />
                                                            </td>
                                                        </tr>
                                                        <tr style='font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;'>
                                                            <td class='content-block' style='font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;' valign='top'>
                                                            If you have not requested this password, and you suspect you were locked out of your account because of changes made by someone
                                                            else, you should contact us at <a href='mailto:info@satvatechnology.co.in'>info@satvatechnology.co.in</a>.
                                                            </td>
                                                        </tr>
                                                        <tr style='font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;'>
                                                            <td class='content-block' style='font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;' valign='top'>
                                                                We may need to send you critical information about our service and it is important that we have an accurate email address.
                                                            </td>
                                                        </tr>
                                                        <tr style='font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;'>
                                                            <td class='content-block' itemprop='handler' itemscope itemtype='http://schema.org/HttpActionHandler' style='font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;' valign='top'>
                                                            Your password for the dashboard is :-" . $password . "
                                                            </td>
                                                        </tr>
                                                        <tr style='font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;'>
                                                            <td class='content-block' style='font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;' valign='top'>
                                                                &mdash; <b>GreenHill</b> - Consulting LLP
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                </td>
                                <td style='font-family: Helvetica Neue,Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0;' valign='top'></td>
                            </tr>
                        </table>
                        </body>

                        </html>";
            $email_to = $email;
            $email_subject = "Your Password for Calendar Test Admin Dashboard";
            $from = "no-reply@satvatechnology.co.in";
            $headers = "From: no-reply@satvatechnology.co.in \r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            $success = mail($email_to, $email_subject, $mailbody, $headers);
            if ($success) {
                header('location:thank-you.php?spass');
                exit;
            } else {
                $errormsg = "<div id='messageerror' class='alert alert-danger font-weight-bold'><i class='mdi mdi-block-helper mr-2'></i> Mail send fail </div>";
            }
        }
    } else {
        $errormsg = "<div id='messageerror' class='alert alert-danger font-weight-bold'><i class='mdi mdi-block-helper mr-2'></i> Email doesn't exist</div>";
    }
} else {
    $errormsg = "<div id='messageerror' class='alert alert-danger font-weight-bold'><i class='mdi mdi-block-helper mr-2'></i> Not Post Back </div>";
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Forgot Password :: Calendar Test</title>
    <?php include('cssjs.php'); ?>
    <script src="js/js-ajex.js"></script>
    <script>
        $(document).ready(function() {
            $('#messagegreen').fadeIn('slow').delay(2500).fadeOut('slow');
            $('#messageerror').fadeIn('slow').delay(2500).fadeOut('slow');
        });
    </script>
</head>

<body class="authentication-bg authentication-bg-pattern">
    <div class="account-pages mt-4 mb-4">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-5">
                    <div class="card bg-pattern">
                        <div class="card-body p-4">
                            <div class="text-center w-75 m-auto">
                                <div class="auth-brand">
                                    <a href="#" class="logo logo-dark text-center">
                                        <span class="logo-lg">
                                            <img src="images/logo.png" alt="" height="76">
                                        </span>
                                    </a>
                                </div>
                                <p class="text-muted mb-2 mt-2">Enter your email address and we'll send you an email with password.</p>
                            </div>
                            <form method="post" enctype="multipart/form-data" action="#" autocomplete="off">
                                <div class="mb-3">
                                    <label for="txtemail">Email id</label>
                                    <input type="email" id="txtemail" name="txtemail" class="form-control" placeholder="Enter your email id" tabindex="1" autofocus required />
                                    <div id="messageerror"><?php echo $errormsg; ?></div>
                                </div>
                                <div class="d-grid">
                                    <button class="btn btn-success btn-block" type="submit" id="btnsubmit" name="btnsubmit"> Reset Password </button>
                                </div>
                            </form>
                            <hr />
                            <p class="m-0 text-center font-bold">Already have an account?</p>
                            <a href="index.php" class="btn w-100 btn-primary waves-effect waves-light mt-3">Back to Sign-in</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="footer footer-alt text-white-50">
        2024 - <script>
            document.write(new Date().getFullYear())
        </script> &copy; Calendar Test </a>
    </footer>
    <?php include('bottom.php'); ?>
</body>

</html>