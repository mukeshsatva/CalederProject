<?php
include('lib/connect.php');

?>


<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- App favicon -->
<link rel="shortcut icon" href="images/logo.png">


<link href="libs/fullcalendar/main.min.css" rel="stylesheet" type="text/css" />

<!-- Plugins css -->
<link href="libs/dropzone/min/dropzone.min.css" rel="stylesheet" type="text/css" />
<link href="libs/dropify/css/dropify.min.css" rel="stylesheet" type="text/css" />
<link href="libs/flatpickr/flatpickr.min.css" rel="stylesheet" type="text/css" />
<link href="libs/mohithg-switchery/switchery.min.css" rel="stylesheet" type="text/css" />
<link href="libs/multiselect/css/multi-select.css" rel="stylesheet" type="text/css" />
<link href="libs/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<link href="libs/selectize/css/selectize.bootstrap3.css" rel="stylesheet" type="text/css" />
<!-- third party css -->
<link href="libs/datatables.net-bs5/css/dataTables.bootstrap5.min.css" rel="stylesheet" type="text/css" />
<link href="libs/datatables.net-responsive-bs5/css/responsive.bootstrap5.min.css" rel="stylesheet" type="text/css" />
<link href="libs/datatables.net-buttons-bs5/css/buttons.bootstrap5.min.css" rel="stylesheet" type="text/css" />
<link href="libs/datatables.net-select-bs5/css//select.bootstrap5.min.css" rel="stylesheet" type="text/css" />
<!-- DataTables FixedColumns CSS -->
<!-- third party css end -->

<link href="libs/jquery-toast-plugin/jquery.toast.min.css" rel="stylesheet" type="text/css" />
<link href="libs/ladda/ladda.min.css" rel="stylesheet" type="text/css" />
<link href="libs/ladda/ladda-themeless.min.css" rel="stylesheet" type="text/css" />
<!-- Theme Config Js -->
<script src="js/head.js"></script>

<!-- Bootstrap css -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" id="app-style" />

<!-- App css -->
<link href="css/app.min.css" rel="stylesheet" type="text/css" />

<!-- Icons css -->
<link href="css/icons.min.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/jquery-ui.css">
<link rel="stylesheet" href="css/fixedColumns.dataTables.min.css">