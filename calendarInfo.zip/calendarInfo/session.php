<?php
if (empty($_SESSION)) //if the session yet not started
	session_start();


if ((!$_SESSION['userid'])) //if not yet logged in
{
	header("refresh:5");
	header("location:logout.php");
	// header("location:https://transdirectory.in/ghconsultancy/logout.php");
	exit;
	echo "<script>alert('login');</script>";
} else {
	$UserId = $_SESSION['userid'];
	$UserName = $_SESSION['userfirstname'];
	$UserType = $_SESSION['usertype'];
	$coid = $_SESSION['coid'];
	$companyname = $_SESSION['coname'];
	$lastLoginTIme = $_SESSION['lastLoginTIme'];
	$IP = $_SESSION['IP'];
}
?>